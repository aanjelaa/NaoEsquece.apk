# Não Esquece

Alarme para quem esquece: quando toca, **só existe soneca**.
Ele só para de vez quando você abre o app, lê a anotação e **segura o botão FEITO**.

- Cada alarme tem um bloco de notas com o "porquê" dele
- Soneca de 1, 3, 5, 10 ou 15 minutos
- Se você ignorar, entra em soneca sozinho após 3 minutos e volta a tocar
- Uma vez, todo dia ou de segunda a sexta
- Papel de parede, cor principal, cor de fundo e som do alarme à sua escolha
- Continua funcionando depois de reiniciar o celular

## Baixar
Abra a página **Releases** deste repositório no celular e baixe `NaoEsquece.apk`.
Cada alteração enviada para cá gera uma versão nova automaticamente.
