using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace NaoEsquecePC
{
    /// <summary>
    /// Fica na bandeja (perto do relógio), confere os alarmes a cada poucos segundos,
    /// mostra os avisos antes da hora e abre a janela de alarme na hora certa.
    /// </summary>
    public class Motor : ApplicationContext
    {
        public static Motor Instancia;
        public event EventHandler Mudou;

        const string ChaveRun = @"Software\Microsoft\Windows\CurrentVersion\Run";
        static readonly TimeSpan SonecaAutomatica = TimeSpan.FromMinutes(3);

        readonly NotifyIcon icone;
        readonly System.Windows.Forms.Timer relogio;
        readonly Control invocador;
        readonly Dictionary<int, JanelaAlarme> alarmesAbertos = new Dictionary<int, JanelaAlarme>();
        readonly EventWaitHandle sinalAbrir;
        JanelaPrincipal principal;
        SoundPlayer som;
        System.Windows.Forms.Timer somReserva;

        public Motor(bool abrirJanela)
        {
            Instancia = this;
            invocador = new Control();
            invocador.CreateControl();

            icone = new NotifyIcon();
            icone.Icon = Tema.IconeApp;
            icone.Text = "Não Esquece";
            icone.Visible = true;

            var menu = new ContextMenuStrip();
            menu.Items.Add("Abrir Não Esquece", null, (s, e) => AbrirPrincipal());
            menu.Items.Add("Novo lembrete", null, (s, e) => NovoLembrete());
            menu.Items.Add(new ToolStripSeparator());
            var iniciar = new ToolStripMenuItem("Iniciar com o Windows");
            iniciar.Click += (s, e) =>
            {
                InicioAutomatico = !InicioAutomatico;
                iniciar.Checked = InicioAutomatico;
            };
            menu.Opening += (s, e) => iniciar.Checked = InicioAutomatico;
            menu.Items.Add(iniciar);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Sair", null, (s, e) => Sair());
            icone.ContextMenuStrip = menu;
            icone.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) AbrirPrincipal(); };
            icone.BalloonTipClicked += (s, e) => AbrirPrincipal();

            // Na primeira vez, já deixa ligado para iniciar com o Windows
            if (!Armazem.Dados.Config.JaIniciou)
            {
                InicioAutomatico = true;
                Armazem.Dados.Config.JaIniciou = true;
                Armazem.Salvar();
            }
            else if (InicioAutomatico)
            {
                InicioAutomatico = true; // atualiza o caminho, caso o arquivo tenha mudado de pasta
            }

            AjustarPerdidos();

            relogio = new System.Windows.Forms.Timer();
            relogio.Interval = 5000;
            relogio.Tick += (s, e) => Verificar();
            relogio.Start();

            // Se abrirem o programa de novo, só mostra a janela que já está rodando
            sinalAbrir = new EventWaitHandle(false, EventResetMode.AutoReset, "NaoEsquecePC_abrir");
            var t = new Thread(() =>
            {
                while (true)
                {
                    sinalAbrir.WaitOne();
                    try { invocador.BeginInvoke(new Action(AbrirPrincipal)); }
                    catch { return; }
                }
            });
            t.IsBackground = true;
            t.Start();

            if (abrirJanela) AbrirPrincipal();
            Verificar();
        }

        // ---------- iniciar com o Windows ----------

        public static bool InicioAutomatico
        {
            get
            {
                try
                {
                    using (var k = Registry.CurrentUser.OpenSubKey(ChaveRun))
                        return k != null && k.GetValue("NaoEsquece") != null;
                }
                catch { return false; }
            }
            set
            {
                try
                {
                    using (var k = Registry.CurrentUser.CreateSubKey(ChaveRun))
                    {
                        if (value) k.SetValue("NaoEsquece", "\"" + Application.ExecutablePath + "\" --bandeja");
                        else k.DeleteValue("NaoEsquece", false);
                    }
                }
                catch { }
            }
        }

        // ---------- janelas ----------

        public void AbrirPrincipal()
        {
            if (principal == null || principal.IsDisposed)
            {
                principal = new JanelaPrincipal();
            }
            principal.Show();
            if (principal.WindowState == FormWindowState.Minimized) principal.WindowState = FormWindowState.Normal;
            principal.Activate();
            principal.BringToFront();
        }

        public void NovoLembrete()
        {
            AbrirPrincipal();
            principal.Novo();
        }

        public void AvisarBandejaNaPrimeiraVez()
        {
            if (Armazem.Dados.Config.JaAvisouBandeja) return;
            Armazem.Dados.Config.JaAvisouBandeja = true;
            Armazem.Salvar();
            icone.ShowBalloonTip(6000, "Continuo funcionando aqui",
                "O Não Esquece fica perto do relógio e avisa na hora certa. Clique no ícone para abrir.",
                ToolTipIcon.Info);
        }

        public void AvisarMudanca()
        {
            var h = Mudou;
            if (h != null) h(this, EventArgs.Empty);
        }

        void Sair()
        {
            var r = MessageBox.Show(
                "Se você sair, os alarmes do computador NÃO vão tocar até abrir o Não Esquece de novo.\n\nSair mesmo assim?",
                "Não Esquece", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (r != DialogResult.Yes) return;
            PararSom();
            icone.Visible = false;
            icone.Dispose();
            ExitThread();
        }

        // ---------- verificação dos alarmes ----------

        /// <summary>Alarme que repete e ficou muito atrasado (PC desligado) pula para a próxima vez.</summary>
        void AjustarPerdidos()
        {
            DateTime agora = DateTime.Now;
            foreach (var l in Armazem.Dados.Lembretes)
            {
                if (!l.Ativo || l.Status != Lembrete.AGENDADO) continue;
                if (l.Repete && l.Proximo < agora.AddHours(-12))
                {
                    l.Proximo = l.CalcularProximo(agora);
                    l.AvisosDados.Clear();
                }
            }
            Armazem.Salvar();
        }

        void Verificar()
        {
            DateTime agora = DateTime.Now;
            bool mudou = false;
            foreach (var l in Armazem.Dados.Lembretes.ToList())
            {
                if (!l.Ativo) continue;

                if (l.Status == Lembrete.TOCANDO)
                {
                    JanelaAlarme j;
                    if (!alarmesAbertos.TryGetValue(l.Id, out j) || j.IsDisposed) Tocar(l);
                    continue;
                }

                if (agora >= l.Proximo)
                {
                    Tocar(l);
                    mudou = true;
                    continue;
                }

                if (l.Status != Lembrete.AGENDADO) continue;

                // Avisos antes da hora: marca os que já passaram e mostra só um
                bool avisar = false;
                for (int i = 0; i < Lembrete.AvisoOpcoes.Length; i++)
                {
                    if ((l.Avisos & (1 << i)) == 0) continue;
                    DateTime quando = l.Proximo.AddMinutes(-Lembrete.AvisoOpcoes[i]);
                    string chave = l.Proximo.Ticks + ":" + i;
                    if (agora >= quando && !l.AvisosDados.Contains(chave))
                    {
                        l.AvisosDados.Add(chave);
                        avisar = true;
                        mudou = true;
                    }
                }
                if (avisar) MostrarAviso(l, agora);
            }
            if (mudou)
            {
                Armazem.Salvar();
                AvisarMudanca();
            }
        }

        static string Curto(string s, int max)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            s = s.Trim();
            return s.Length <= max ? s : s.Substring(0, max - 1) + "…";
        }

        void MostrarAviso(Lembrete l, DateTime agora)
        {
            string titulo = Curto("Daqui a " + Lembrete.FaltaTexto(l.Proximo - agora) + ": " + l.TituloOuPadrao, 60);
            string texto = "Toca " + Lembrete.DiaTexto(l.Proximo) + " às " + l.Proximo.ToString("HH:mm");
            if (!string.IsNullOrWhiteSpace(l.Nota)) texto += "\n" + l.Nota.Trim();
            icone.ShowBalloonTip(15000, titulo, Curto(texto, 250), ToolTipIcon.Info);
        }

        // ---------- tocar / soneca / feito ----------

        void Tocar(Lembrete l)
        {
            l.Status = Lembrete.TOCANDO;
            Armazem.Salvar();

            JanelaAlarme j;
            if (!alarmesAbertos.TryGetValue(l.Id, out j) || j.IsDisposed)
            {
                int id = l.Id;
                j = new JanelaAlarme(id, SonecaAutomatica);
                alarmesAbertos[id] = j;
                JanelaAlarme esta = j;
                j.FormClosed += (s, e) =>
                {
                    JanelaAlarme atual;
                    if (alarmesAbertos.TryGetValue(id, out atual) && atual == esta) alarmesAbertos.Remove(id);
                    if (alarmesAbertos.Count == 0) PararSom();
                };
                j.Show();
            }
            j.Trazer();
            IniciarSom();
            icone.ShowBalloonTip(10000, Curto("⏰ " + l.TituloOuPadrao, 60),
                Curto(string.IsNullOrWhiteSpace(l.Nota) ? "Hora do lembrete!" : l.Nota, 250), ToolTipIcon.Warning);
            AvisarMudanca();
        }

        public void Soneca(int id)
        {
            var l = Armazem.Buscar(id);
            if (l != null && l.Ativo)
            {
                l.Status = Lembrete.SONECA;
                l.Sonecas++;
                l.Proximo = DateTime.Now.AddMinutes(l.SonecaMin);
                Armazem.Salvar();
            }
            FecharAlarme(id);
            AvisarMudanca();
        }

        /// <summary>Usado quando a janela do alarme é fechada no X: vira soneca.</summary>
        public void SonecaDepois(int id)
        {
            invocador.BeginInvoke(new Action(() => Soneca(id)));
        }

        public void Feito(int id)
        {
            var l = Armazem.Buscar(id);
            if (l != null)
            {
                l.MarcarFeito();
                Armazem.Salvar();
            }
            FecharAlarme(id);
            AvisarMudanca();
        }

        public void FecharAlarme(int id)
        {
            JanelaAlarme j;
            if (alarmesAbertos.TryGetValue(id, out j))
            {
                alarmesAbertos.Remove(id);
                j.FecharSemSoneca();
            }
            if (alarmesAbertos.Count == 0) PararSom();
        }

        public void AbrirAlarme(int id)
        {
            JanelaAlarme j;
            if (alarmesAbertos.TryGetValue(id, out j) && !j.IsDisposed)
            {
                j.Trazer();
                return;
            }
            // Em soneca: abre a janela para ver a anotação e marcar como feito
            var nova = new JanelaAlarme(id, TimeSpan.Zero);
            nova.Show();
            nova.Trazer();
        }

        public void CriarTeste()
        {
            var l = new Lembrete();
            l.Titulo = "Alarme de teste";
            l.Nota = "Isto é um teste.\r\n\r\nRepare: só existe SONECA. Fechar a janela também vira soneca. "
                     + "Para desligar de vez, segure o botão FEITO até a barra encher.";
            DateTime quando = DateTime.Now.AddSeconds(10);
            l.Data = quando.Date;
            l.Hora = quando.Hour;
            l.Minuto = quando.Minute;
            l.SonecaMin = 1;
            l.Proximo = quando;
            l.Status = Lembrete.AGENDADO;
            Armazem.Adicionar(l);
            AvisarMudanca();
        }

        // ---------- som ----------

        void IniciarSom()
        {
            if (som != null || somReserva != null) return;
            string arq = Tema.ArquivoSom();
            if (arq != null)
            {
                try
                {
                    som = new SoundPlayer(arq);
                    som.Load();
                    som.PlayLooping();
                    return;
                }
                catch
                {
                    if (som != null) som.Dispose();
                    som = null;
                }
            }
            somReserva = new System.Windows.Forms.Timer();
            somReserva.Interval = 1500;
            somReserva.Tick += (s, e) => SystemSounds.Exclamation.Play();
            somReserva.Start();
        }

        public void PararSom()
        {
            if (som != null)
            {
                try { som.Stop(); } catch { }
                som.Dispose();
                som = null;
            }
            if (somReserva != null)
            {
                somReserva.Stop();
                somReserva.Dispose();
                somReserva = null;
            }
        }

        SoundPlayer somTeste;

        public void TestarSom(string arquivo)
        {
            try
            {
                if (somTeste != null) { somTeste.Stop(); somTeste.Dispose(); }
                somTeste = new SoundPlayer(arquivo);
                somTeste.Play();
            }
            catch
            {
                MessageBox.Show("Não consegui tocar esse arquivo. Escolha um arquivo .wav.", "Não Esquece");
            }
        }
    }
}
