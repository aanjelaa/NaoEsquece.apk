using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    /// <summary>
    /// Janela que aparece por cima de tudo quando o alarme toca.
    /// Mostra a anotação e só oferece Soneca ou segurar FEITO. Fechar no X vira soneca.
    /// </summary>
    public class JanelaAlarme : FormaTema
    {
        const double SEGURAR_MS = 1500;

        readonly int id;
        readonly bool tocando;
        bool acaoFeita;
        readonly Panel botaoFeito;
        readonly Timer progresso;
        readonly Timer automatico;
        readonly Label dica;
        DateTime inicioToque;
        double pct;

        [StructLayout(LayoutKind.Sequential)]
        struct FLASHWINFO
        {
            public uint cbSize;
            public IntPtr hwnd;
            public uint dwFlags;
            public uint uCount;
            public uint dwTimeout;
        }

        [DllImport("user32.dll")]
        static extern bool FlashWindowEx(ref FLASHWINFO pwfi);

        public JanelaAlarme(int id, TimeSpan sonecaAutomatica)
        {
            this.id = id;
            tocando = sonecaAutomatica > TimeSpan.Zero;
            var l = Armazem.Buscar(id) ?? new Lembrete();

            Text = "Não Esquece — " + l.TituloOuPadrao;
            TopMost = tocando;
            ShowInTaskbar = true;
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = !tocando;
            ClientSize = new Size(Tema.S(440), Tema.S(560));
            Color txt = Tema.TextoSobreFundo;
            int m = Tema.S(22);
            int largura = ClientSize.Width - 2 * m;
            int y = Tema.S(18);

            var sino = Tema.Texto(tocando ? "⏰" : "😴", new Font("Segoe UI Emoji", 30f), txt);
            sino.AutoSize = false;
            sino.TextAlign = ContentAlignment.MiddleCenter;
            sino.SetBounds(m, y, largura, Tema.S(60));
            Controls.Add(sino);
            y += Tema.S(60);

            var hora = Tema.Texto(DateTime.Now.ToString("HH:mm"), Tema.Fonte(12f), txt);
            hora.AutoSize = false;
            hora.TextAlign = ContentAlignment.MiddleCenter;
            hora.SetBounds(m, y, largura, Tema.S(26));
            Controls.Add(hora);
            y += Tema.S(28);

            var titulo = Tema.Texto(l.TituloOuPadrao, Tema.FonteMedia(18f), txt);
            titulo.AutoSize = false;
            titulo.TextAlign = ContentAlignment.MiddleCenter;
            titulo.AutoEllipsis = true;
            titulo.SetBounds(m, y, largura, Tema.S(40));
            Controls.Add(titulo);
            y += Tema.S(42);

            string sub = tocando
                ? (l.Sonecas > 0 ? "Você já apertou soneca " + l.Sonecas + "x" : "")
                : "Em soneca — volta a tocar às " + l.Proximo.ToString("HH:mm");
            var subt = Tema.Texto(sub, Tema.Fonte(10f), txt);
            subt.AutoSize = false;
            subt.TextAlign = ContentAlignment.MiddleCenter;
            subt.SetBounds(m, y, largura, Tema.S(22));
            Controls.Add(subt);
            y += Tema.S(28);

            // Anotação: o porquê do alarme
            int alturaNota = ClientSize.Height - y - Tema.S(150);
            var cartao = new Panel();
            cartao.BackColor = Color.White;
            cartao.SetBounds(m, y, largura, alturaNota);
            cartao.Padding = new Padding(Tema.S(14));
            Tema.Arredondar(cartao, Tema.S(16));
            var rotulo = Tema.Rotulo("Por que está tocando");
            rotulo.BackColor = Color.White;
            rotulo.Dock = DockStyle.Top;
            var nota = new TextBox();
            nota.Multiline = true;
            nota.ReadOnly = true;
            nota.BorderStyle = BorderStyle.None;
            nota.BackColor = Color.White;
            nota.ForeColor = Tema.TextoEscuro;
            nota.Font = Tema.Fonte(13f);
            nota.ScrollBars = ScrollBars.Vertical;
            nota.Text = string.IsNullOrWhiteSpace(l.Nota) ? "(sem anotação)" : l.Nota.Trim().Replace("\r\n", "\n").Replace("\n", "\r\n");
            nota.Dock = DockStyle.Fill;
            nota.TabStop = false;
            cartao.Controls.Add(nota);
            cartao.Controls.Add(rotulo);
            Controls.Add(cartao);
            y += alturaNota + Tema.S(14);

            if (tocando)
            {
                var soneca = Tema.Botao("Soneca " + l.SonecaMin + " min", Tema.Laranja);
                soneca.Font = Tema.FonteMedia(12f);
                soneca.SetBounds(m, y, largura, Tema.S(50));
                soneca.Click += (s, e) =>
                {
                    acaoFeita = true;
                    Motor.Instancia.Soneca(this.id);
                };
                Controls.Add(soneca);
            }
            y += Tema.S(58);

            // Botão FEITO: precisa segurar, para não desligar no automático
            botaoFeito = new Panel();
            botaoFeito.SetBounds(m, y, largura, Tema.S(50));
            botaoFeito.Cursor = Cursors.Hand;
            botaoFeito.BackColor = Color.FromArgb(102, 187, 106);
            Tema.Arredondar(botaoFeito, Tema.S(25));
            botaoFeito.Paint += PintarFeito;
            botaoFeito.MouseDown += (s, e) =>
            {
                if (e.Button != MouseButtons.Left) return;
                inicioToque = DateTime.Now;
                dica.Visible = false;
                progresso.Start();
            };
            botaoFeito.MouseUp += (s, e) => SoltouFeito(true);
            botaoFeito.MouseLeave += (s, e) => SoltouFeito(false);
            Controls.Add(botaoFeito);

            dica = Tema.Texto("Segure o botão até a barra encher", Tema.Fonte(9f), txt);
            dica.AutoSize = false;
            dica.TextAlign = ContentAlignment.MiddleCenter;
            dica.SetBounds(m, y + Tema.S(52), largura, Tema.S(20));
            dica.Visible = false;
            Controls.Add(dica);

            progresso = new Timer();
            progresso.Interval = 30;
            progresso.Tick += (s, e) =>
            {
                pct = Math.Min(1.0, (DateTime.Now - inicioToque).TotalMilliseconds / SEGURAR_MS);
                botaoFeito.Invalidate();
                if (pct >= 1.0)
                {
                    progresso.Stop();
                    acaoFeita = true;
                    Motor.Instancia.Feito(this.id);
                    if (!IsDisposed) Close();
                }
            };

            automatico = new Timer();
            if (tocando)
            {
                automatico.Interval = (int)sonecaAutomatica.TotalMilliseconds;
                automatico.Tick += (s, e) =>
                {
                    automatico.Stop();
                    acaoFeita = true;
                    Motor.Instancia.Soneca(this.id);
                };
                automatico.Start();
            }

            FormClosing += (s, e) =>
            {
                if (acaoFeita || !tocando) return;
                if (e.CloseReason == CloseReason.WindowsShutDown || e.CloseReason == CloseReason.TaskManagerClosing) return;
                // Fechar no X = soneca (o alarme volta a tocar depois)
                acaoFeita = true;
                Motor.Instancia.SonecaDepois(this.id);
            };
            FormClosed += (s, e) =>
            {
                progresso.Stop();
                automatico.Stop();
                progresso.Dispose();
                automatico.Dispose();
            };
        }

        void SoltouFeito(bool mostrarDica)
        {
            if (!progresso.Enabled) return;
            progresso.Stop();
            if (pct < 1.0)
            {
                pct = 0;
                botaoFeito.Invalidate();
                if (mostrarDica) dica.Visible = true;
            }
        }

        void PintarFeito(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var r = botaoFeito.ClientRectangle;
            if (pct > 0)
            {
                using (var b = new SolidBrush(Color.FromArgb(27, 94, 32)))
                    g.FillRectangle(b, 0, 0, (int)(r.Width * pct), r.Height);
            }
            TextRenderer.DrawText(g, "Segure para marcar FEITO", Tema.FonteMedia(12f), r, Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        /// <summary>Traz a janela para frente e pisca na barra de tarefas.</summary>
        public void Trazer()
        {
            if (IsDisposed) return;
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Show();
            Activate();
            BringToFront();
            try
            {
                var f = new FLASHWINFO();
                f.cbSize = (uint)Marshal.SizeOf(typeof(FLASHWINFO));
                f.hwnd = Handle;
                f.dwFlags = 3 | 12; // FLASHW_ALL | FLASHW_TIMERNOFG
                f.uCount = uint.MaxValue;
                f.dwTimeout = 0;
                FlashWindowEx(ref f);
            }
            catch { }
        }

        /// <summary>Fecha sem transformar em soneca (a decisão já foi tomada).</summary>
        public void FecharSemSoneca()
        {
            acaoFeita = true;
            if (!IsDisposed) Close();
        }
    }
}
