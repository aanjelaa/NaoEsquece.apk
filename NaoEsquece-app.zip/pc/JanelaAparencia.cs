using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    /// <summary>Papel de parede, cores, som, iniciar com o Windows, backup e teste.</summary>
    public class JanelaAparencia : Form
    {
        readonly FlowLayoutPanel corpo;

        public JanelaAparencia()
        {
            Text = "Aparência e ajustes";
            if (Tema.IconeApp != null) Icon = Tema.IconeApp;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(245, 245, 245);
            Font = Tema.Fonte(10f);
            ClientSize = new Size(Tema.S(440), Tema.S(640));

            corpo = new FlowLayoutPanel();
            corpo.Dock = DockStyle.Fill;
            corpo.FlowDirection = FlowDirection.TopDown;
            corpo.WrapContents = false;
            corpo.AutoScroll = true;
            corpo.Padding = new Padding(Tema.S(16));
            Controls.Add(corpo);
            Montar();
        }

        int Largura { get { return ClientSize.Width - Tema.S(32) - SystemInformation.VerticalScrollBarWidth; } }

        void Montar()
        {
            corpo.SuspendLayout();
            foreach (Control c in corpo.Controls.Cast<Control>().ToList()) c.Dispose();
            corpo.Controls.Clear();

            // Papel de parede
            var c1 = Cartao("Papel de parede");
            var escolher = Tema.Botao("Escolher imagem", Tema.Cor);
            escolher.Width = Largura - Tema.S(28);
            escolher.Click += (s, e) => EscolherPapel();
            Adicionar(c1, escolher);
            if (Tema.Papel() != null)
            {
                Adicionar(c1, Tema.Texto("Escurecer a imagem (para ler melhor)", Tema.Fonte(9f), Tema.TextoCinza));
                var barra = new TrackBar();
                barra.Minimum = 0;
                barra.Maximum = 80;
                barra.TickFrequency = 10;
                barra.Value = Armazem.Dados.Config.Escurecer;
                barra.Width = Largura - Tema.S(28);
                barra.BackColor = Color.White;
                barra.MouseUp += (s, e) =>
                {
                    Armazem.Dados.Config.Escurecer = barra.Value;
                    Armazem.Salvar();
                };
                Adicionar(c1, barra);
                var remover = Tema.Botao("Remover papel de parede", Color.FromArgb(117, 117, 117));
                remover.Width = Largura - Tema.S(28);
                remover.Click += (s, e) =>
                {
                    Armazem.Dados.Config.Papel = null;
                    Armazem.Salvar();
                    Tema.LimparCachePapel();
                    BeginInvoke(new Action(Montar));
                };
                Adicionar(c1, remover);
            }
            corpo.Controls.Add(c1);

            // Cores
            var c2 = Cartao("Cor principal");
            Adicionar(c2, Paleta(Tema.Cores, Armazem.Dados.Config.Cor, cor => Armazem.Dados.Config.Cor = cor));
            corpo.Controls.Add(c2);

            var c3 = Cartao("Cor de fundo" + (Tema.Papel() != null ? " (quando não tem imagem)" : ""));
            Adicionar(c3, Paleta(Tema.Fundos, Armazem.Dados.Config.Fundo, cor => Armazem.Dados.Config.Fundo = cor));
            corpo.Controls.Add(c3);

            // Som
            var c4 = Cartao("Som do alarme");
            string atual = Tema.ArquivoSom();
            Adicionar(c4, Tema.Texto(atual == null ? "Som do sistema" : Path.GetFileName(atual), Tema.Fonte(9f), Tema.TextoCinza));
            var som = Tema.Botao("Escolher som (.wav)", Tema.Cor);
            som.Width = Largura - Tema.S(28);
            som.Click += (s, e) => EscolherSom();
            Adicionar(c4, som);
            if (!string.IsNullOrEmpty(Armazem.Dados.Config.Som))
            {
                var padrao = Tema.Botao("Voltar ao som padrão", Color.FromArgb(117, 117, 117));
                padrao.Width = Largura - Tema.S(28);
                padrao.Click += (s, e) =>
                {
                    Armazem.Dados.Config.Som = null;
                    Armazem.Salvar();
                    BeginInvoke(new Action(Montar));
                };
                Adicionar(c4, padrao);
            }
            corpo.Controls.Add(c4);

            // Iniciar com o Windows
            var c5 = Cartao("Funcionamento");
            var iniciar = new CheckBox();
            iniciar.Text = "Iniciar junto com o Windows (recomendado)";
            iniciar.AutoSize = true;
            iniciar.Checked = Motor.InicioAutomatico;
            iniciar.CheckedChanged += (s, e) => Motor.InicioAutomatico = iniciar.Checked;
            Adicionar(c5, iniciar);
            Adicionar(c5, Tema.Texto("O Não Esquece fica perto do relógio e só toca se estiver aberto.",
                Tema.Fonte(9f), Tema.TextoCinza));
            var testar = Tema.Botao("Tocar alarme de teste (em 10 segundos)", Tema.Verde);
            testar.Width = Largura - Tema.S(28);
            testar.Click += (s, e) =>
            {
                Motor.Instancia.CriarTeste();
                MessageBox.Show(this, "Vai tocar em 10 segundos…", "Não Esquece");
            };
            Adicionar(c5, testar);
            corpo.Controls.Add(c5);

            // Backup
            var c6 = Cartao("Backup");
            Adicionar(c6, Tema.Texto("Salve uma cópia dos seus lembretes. Dica: salve na pasta do\nGoogle Drive do computador, se tiver.",
                Tema.Fonte(9f), Tema.TextoCinza));
            var exportar = Tema.Botao("Salvar cópia…", Tema.Cor);
            exportar.Width = Largura - Tema.S(28);
            exportar.Click += (s, e) => Exportar();
            Adicionar(c6, exportar);
            var importar = Tema.Botao("Restaurar de uma cópia…", Color.FromArgb(96, 125, 139));
            importar.Width = Largura - Tema.S(28);
            importar.Click += (s, e) => Importar();
            Adicionar(c6, importar);
            corpo.Controls.Add(c6);

            corpo.ResumeLayout();
        }

        FlowLayoutPanel Cartao(string titulo)
        {
            var p = new FlowLayoutPanel();
            p.FlowDirection = FlowDirection.TopDown;
            p.WrapContents = false;
            p.AutoSize = true;
            p.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            p.BackColor = Color.White;
            p.Padding = new Padding(Tema.S(14), Tema.S(12), Tema.S(14), Tema.S(12));
            p.Margin = new Padding(0, 0, 0, Tema.S(10));
            p.MinimumSize = new Size(Largura, 0);
            p.MaximumSize = new Size(Largura, 0);
            var t = Tema.Texto(titulo, Tema.FonteMedia(11f), Tema.TextoEscuro);
            t.Margin = new Padding(0, 0, 0, Tema.S(6));
            p.Controls.Add(t);
            return p;
        }

        void Adicionar(FlowLayoutPanel cartao, Control c)
        {
            c.Margin = new Padding(0, Tema.S(4), 0, Tema.S(4));
            cartao.Controls.Add(c);
        }

        Control Paleta(string[] cores, string selecionada, Action<string> escolher)
        {
            var p = new FlowLayoutPanel();
            p.AutoSize = true;
            p.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            p.MaximumSize = new Size(Largura - Tema.S(28), 0);
            p.BackColor = Color.White;
            int tam = Tema.S(34);
            foreach (string cor in cores)
            {
                string esta = cor;
                var b = new Button();
                b.FlatStyle = FlatStyle.Flat;
                b.BackColor = Tema.Html(cor);
                b.UseVisualStyleBackColor = false;
                b.FlatAppearance.BorderSize = string.Equals(cor, selecionada, StringComparison.OrdinalIgnoreCase) ? Tema.S(3) : 1;
                b.FlatAppearance.BorderColor = string.Equals(cor, selecionada, StringComparison.OrdinalIgnoreCase)
                    ? Color.FromArgb(33, 33, 33) : Color.FromArgb(200, 200, 200);
                b.Size = new Size(tam, tam);
                b.Margin = new Padding(Tema.S(3));
                b.Cursor = Cursors.Hand;
                b.Click += (s, e) =>
                {
                    escolher(esta);
                    Armazem.Salvar();
                    BeginInvoke(new Action(Montar));
                };
                p.Controls.Add(b);
            }
            return p;
        }

        void EscolherPapel()
        {
            using (var d = new OpenFileDialog())
            {
                d.Title = "Escolha uma imagem para o papel de parede";
                d.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.gif|Todos os arquivos|*.*";
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    string destino = Path.Combine(Armazem.Pasta, "papel" + Path.GetExtension(d.FileName).ToLowerInvariant());
                    Tema.LimparCachePapel();
                    File.Copy(d.FileName, destino, true);
                    Armazem.Dados.Config.Papel = destino;
                    Armazem.Salvar();
                    if (Tema.Papel() == null) throw new Exception("imagem inválida");
                    BeginInvoke(new Action(Montar));
                }
                catch
                {
                    Armazem.Dados.Config.Papel = null;
                    Armazem.Salvar();
                    MessageBox.Show(this, "Não consegui abrir essa imagem.", "Não Esquece");
                }
            }
        }

        void EscolherSom()
        {
            using (var d = new OpenFileDialog())
            {
                d.Title = "Escolha um som (.wav)";
                d.Filter = "Sons WAV|*.wav";
                string media = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Media");
                if (Directory.Exists(media)) d.InitialDirectory = media;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                Armazem.Dados.Config.Som = d.FileName;
                Armazem.Salvar();
                Motor.Instancia.TestarSom(d.FileName);
                BeginInvoke(new Action(Montar));
            }
        }

        void Exportar()
        {
            using (var d = new SaveFileDialog())
            {
                d.Title = "Salvar cópia dos lembretes";
                d.Filter = "Backup do Não Esquece|*.json";
                d.FileName = "NaoEsquece-PC-backup.json";
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    File.WriteAllText(d.FileName, Armazem.Serializar(Armazem.Dados), Encoding.UTF8);
                    MessageBox.Show(this, "Cópia salva ✓", "Não Esquece");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Não consegui salvar: " + ex.Message, "Não Esquece");
                }
            }
        }

        void Importar()
        {
            using (var d = new OpenFileDialog())
            {
                d.Title = "Escolha a cópia para restaurar";
                d.Filter = "Backup do Não Esquece|*.json|Todos os arquivos|*.*";
                if (d.ShowDialog(this) != DialogResult.OK) return;
                Pacote p;
                try
                {
                    p = Armazem.Desserializar(File.ReadAllText(d.FileName, Encoding.UTF8));
                }
                catch
                {
                    MessageBox.Show(this, "Esse arquivo não é uma cópia do Não Esquece para computador.", "Não Esquece");
                    return;
                }
                var resp = MessageBox.Show(this,
                    "A cópia tem " + p.Lembretes.Count + " lembrete(s). Eles vão substituir os "
                    + Armazem.Dados.Lembretes.Count + " que estão aqui agora. Continuar?",
                    "Restaurar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp != DialogResult.Yes) return;

                foreach (var l in Armazem.Dados.Lembretes.ToList()) Motor.Instancia.FecharAlarme(l.Id);
                DateTime agora = DateTime.Now;
                foreach (var l in p.Lembretes)
                {
                    l.Sonecas = 0;
                    l.AvisosDados.Clear();
                    if (!l.Ativo) continue;
                    if (l.Repete)
                    {
                        l.Status = Lembrete.AGENDADO;
                        l.Proximo = l.CalcularProximo(agora);
                    }
                    else
                    {
                        DateTime quando = l.CalcularProximo(agora);
                        l.Status = quando <= agora ? Lembrete.FEITO : Lembrete.AGENDADO;
                        l.Proximo = quando;
                    }
                }
                p.Config.JaIniciou = true;
                p.Config.JaAvisouBandeja = Armazem.Dados.Config.JaAvisouBandeja;
                if (!string.IsNullOrEmpty(p.Config.Papel) && !File.Exists(p.Config.Papel)) p.Config.Papel = null;
                Armazem.Dados = p;
                Armazem.Salvar();
                Tema.LimparCachePapel();
                Motor.Instancia.AvisarMudanca();
                MessageBox.Show(this, p.Lembretes.Count + " lembrete(s) restaurado(s) ✓", "Não Esquece");
                BeginInvoke(new Action(Montar));
            }
        }
    }
}
