using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    /// <summary>Cores, papel de parede, fontes e peças de tela reaproveitadas.</summary>
    public static class Tema
    {
        public static readonly string[] Cores =
        {
            "#7C4DFF", "#E91E63", "#F44336", "#FF9800", "#4CAF50",
            "#009688", "#2196F3", "#3F51B5", "#795548", "#424242"
        };

        public static readonly string[] Fundos =
        {
            "#F3E5F5", "#FCE4EC", "#FFF3E0", "#FFFDE7", "#E8F5E9",
            "#E0F2F1", "#E3F2FD", "#ECEFF1", "#212121", "#1A237E"
        };

        public static float Escala = 1f;
        public static Icon IconeApp;

        public static void Iniciar()
        {
            try
            {
                using (var g = Graphics.FromHwnd(IntPtr.Zero)) Escala = g.DpiX / 96f;
            }
            catch { Escala = 1f; }
            try { IconeApp = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            if (IconeApp == null) IconeApp = SystemIcons.Application;
        }

        public static int S(int px) { return (int)Math.Round(px * Escala); }

        public static Color Html(string hex)
        {
            try { return ColorTranslator.FromHtml(hex); } catch { return Color.MediumPurple; }
        }

        public static Color Cor { get { return Html(Armazem.Dados.Config.Cor); } }
        public static Color Fundo { get { return Html(Armazem.Dados.Config.Fundo); } }

        public static double Luz(Color c) { return (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) / 255.0; }

        public static bool FundoEscuro { get { return Papel() != null || Luz(Fundo) < 0.5; } }

        /// <summary>Cor do texto que fica direto sobre o fundo (fora dos cartões).</summary>
        public static Color TextoSobreFundo { get { return FundoEscuro ? Color.White : Color.FromArgb(33, 33, 33); } }

        public static Color TextoEscuro = Color.FromArgb(33, 33, 33);
        public static Color TextoCinza = Color.FromArgb(117, 117, 117);
        public static Color Verde = Color.FromArgb(46, 125, 50);
        public static Color Laranja = Color.FromArgb(255, 143, 0);
        public static Color Vermelho = Color.FromArgb(211, 47, 47);

        public static Font Fonte(float pt) { return new Font("Segoe UI", pt, FontStyle.Regular); }
        public static Font FonteMedia(float pt) { return new Font("Segoe UI Semibold", pt, FontStyle.Regular); }
        public static Font FonteLeve(float pt) { return new Font("Segoe UI Light", pt, FontStyle.Regular); }

        // ---------- papel de parede ----------

        static Image cachePapel;
        static string cacheCaminho;

        public static Image Papel()
        {
            string p = Armazem.Dados.Config.Papel;
            if (string.IsNullOrEmpty(p) || !File.Exists(p)) return null;
            if (cachePapel != null && cacheCaminho == p) return cachePapel;
            try
            {
                using (var fs = new FileStream(p, FileMode.Open, FileAccess.Read))
                using (var img = Image.FromStream(fs))
                {
                    cachePapel = new Bitmap(img);
                }
                cacheCaminho = p;
                return cachePapel;
            }
            catch
            {
                return null;
            }
        }

        public static void LimparCachePapel()
        {
            if (cachePapel != null) cachePapel.Dispose();
            cachePapel = null;
            cacheCaminho = null;
        }

        /// <summary>Desenha o papel de parede (cobrindo tudo) ou a cor de fundo.</summary>
        public static void PintarFundo(Graphics g, Rectangle area)
        {
            Image img = Papel();
            if (img == null)
            {
                using (var b = new SolidBrush(Fundo)) g.FillRectangle(b, area);
                return;
            }
            float escala = Math.Max((float)area.Width / img.Width, (float)area.Height / img.Height);
            float w = img.Width * escala, h = img.Height * escala;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(img, area.X + (area.Width - w) / 2, area.Y + (area.Height - h) / 2, w, h);
            int alfa = Armazem.Dados.Config.Escurecer * 255 / 100;
            using (var b = new SolidBrush(Color.FromArgb(alfa, 0, 0, 0))) g.FillRectangle(b, area);
        }

        // ---------- som ----------

        public static string ArquivoSom()
        {
            string escolhido = Armazem.Dados.Config.Som;
            if (!string.IsNullOrEmpty(escolhido) && File.Exists(escolhido)) return escolhido;
            string media = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Media");
            string[] candidatos = { "Alarm01.wav", "Alarm02.wav", "Alarm03.wav", "Ring01.wav", "ringout.wav", "Windows Notify System Generic.wav" };
            foreach (string c in candidatos)
            {
                string p = Path.Combine(media, c);
                if (File.Exists(p)) return p;
            }
            return null;
        }

        // ---------- peças de tela ----------

        public static Button Botao(string texto, Color cor)
        {
            var b = new Button();
            b.Text = texto;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = cor;
            b.ForeColor = Luz(cor) > 0.7 ? TextoEscuro : Color.White;
            b.Font = FonteMedia(10.5f);
            b.Height = S(42);
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            Arredondar(b, S(21));
            return b;
        }

        /// <summary>Botãozinho liga/desliga (dias da semana, avisos…).</summary>
        public static CheckBox Chip(string texto)
        {
            var c = new CheckBox();
            c.Appearance = Appearance.Button;
            c.Text = texto;
            c.TextAlign = ContentAlignment.MiddleCenter;
            c.FlatStyle = FlatStyle.Flat;
            c.FlatAppearance.BorderSize = 0;
            c.Font = FonteMedia(9.5f);
            c.Height = S(34);
            c.Cursor = Cursors.Hand;
            c.UseVisualStyleBackColor = false;
            c.CheckedChanged += (s, e) => MarcarChip(c);
            MarcarChip(c);
            Arredondar(c, S(17));
            return c;
        }

        public static void MarcarChip(CheckBox c)
        {
            Color cor = Cor;
            c.BackColor = c.Checked ? cor : Color.FromArgb(238, 238, 238);
            c.ForeColor = c.Checked ? (Luz(cor) > 0.7 ? TextoEscuro : Color.White) : Color.FromArgb(97, 97, 97);
            c.FlatAppearance.CheckedBackColor = cor;
        }

        public static Label Texto(string t, Font f, Color cor)
        {
            var l = new Label();
            l.Text = t;
            l.Font = f;
            l.ForeColor = cor;
            l.BackColor = Color.Transparent;
            l.AutoSize = true;
            return l;
        }

        public static Label Rotulo(string t)
        {
            return Texto(t.ToUpper(Lembrete.BR), FonteMedia(8f), Color.FromArgb(158, 158, 158));
        }

        /// <summary>Cantos arredondados (reaplica quando o tamanho muda).</summary>
        public static void Arredondar(Control c, int raio)
        {
            EventHandler aplicar = (s, e) =>
            {
                if (c.Width <= 0 || c.Height <= 0) return;
                using (var path = Caminho(new Rectangle(0, 0, c.Width, c.Height), raio))
                {
                    c.Region = new Region(path);
                }
            };
            c.Resize += aplicar;
            aplicar(c, EventArgs.Empty);
        }

        public static GraphicsPath Caminho(Rectangle r, int raio)
        {
            int d = Math.Min(raio * 2, Math.Min(r.Width, r.Height));
            var p = new GraphicsPath();
            if (d <= 1)
            {
                p.AddRectangle(r);
                return p;
            }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    /// <summary>Janela que desenha o papel de parede/cor de fundo atrás de tudo.</summary>
    public class FormaTema : Form
    {
        public FormaTema()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            AutoScaleMode = AutoScaleMode.None;
            Font = Tema.Fonte(10f);
            if (Tema.IconeApp != null) Icon = Tema.IconeApp;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Tema.PintarFundo(e.Graphics, ClientRectangle);
        }
    }

    /// <summary>Painel com fundo transparente (mostra o papel de parede da janela).</summary>
    public class PainelTransparente : Panel
    {
        public PainelTransparente()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer
                     | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
            BackColor = Color.Transparent;
        }
    }
}
