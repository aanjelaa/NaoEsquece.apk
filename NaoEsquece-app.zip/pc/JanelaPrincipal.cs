using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    /// <summary>Lista de lembretes.</summary>
    public class JanelaPrincipal : FormaTema
    {
        readonly FlowLayoutPanel lista;
        readonly PainelTransparente topo;
        readonly PainelTransparente rodape;
        readonly EventHandler aoMudar;

        public JanelaPrincipal()
        {
            Text = "Não Esquece";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(Tema.S(430), Tema.S(620));
            MinimumSize = new Size(Tema.S(360), Tema.S(420));

            lista = new FlowLayoutPanel();
            lista.Dock = DockStyle.Fill;
            lista.FlowDirection = FlowDirection.TopDown;
            lista.WrapContents = false;
            lista.AutoScroll = true;
            lista.BackColor = Color.Transparent;
            lista.Padding = new Padding(Tema.S(14), Tema.S(4), Tema.S(14), Tema.S(4));
            lista.Resize += (s, e) => AjustarLarguras();
            lista.Scroll += (s, e) => lista.Invalidate(true);
            lista.MouseWheel += (s, e) => lista.Invalidate(true);

            topo = new PainelTransparente();
            topo.Dock = DockStyle.Top;
            topo.Height = Tema.S(62);

            rodape = new PainelTransparente();
            rodape.Dock = DockStyle.Bottom;
            rodape.Height = Tema.S(68);

            Controls.Add(lista);
            Controls.Add(topo);
            Controls.Add(rodape);

            PerformLayout();
            MontarTopoERodape();
            Recarregar();

            aoMudar = (s, e) => { if (!IsDisposed && IsHandleCreated) BeginInvoke(new Action(Recarregar)); };
            Motor.Instancia.Mudou += aoMudar;
            FormClosed += (s, e) => Motor.Instancia.Mudou -= aoMudar;

            // Fechar no X só esconde: o programa continua na bandeja tocando os alarmes
            FormClosing += (s, e) =>
            {
                if (e.CloseReason == CloseReason.UserClosing)
                {
                    e.Cancel = true;
                    Hide();
                    Motor.Instancia.AvisarBandejaNaPrimeiraVez();
                }
            };
        }

        void MontarTopoERodape()
        {
            foreach (Control c in topo.Controls.Cast<Control>().ToList()) c.Dispose();
            foreach (Control c in rodape.Controls.Cast<Control>().ToList()) c.Dispose();
            topo.Controls.Clear();
            rodape.Controls.Clear();
            Color txt = Tema.TextoSobreFundo;

            var titulo = Tema.Texto("Não Esquece", Tema.FonteMedia(17f), txt);
            titulo.Location = new Point(Tema.S(16), Tema.S(14));
            topo.Controls.Add(titulo);

            var ajustes = Tema.Botao("Aparência", Color.White);
            ajustes.Font = Tema.FonteMedia(9.5f);
            ajustes.Width = Tema.S(110);
            ajustes.Height = Tema.S(34);
            ajustes.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            ajustes.Location = new Point(topo.Width - ajustes.Width - Tema.S(16), Tema.S(16));
            ajustes.Click += (s, e) => BeginInvoke(new Action(AbrirAparencia));
            topo.Controls.Add(ajustes);

            var novo = Tema.Botao("+  Novo lembrete", Tema.Cor);
            novo.Font = Tema.FonteMedia(11.5f);
            novo.Height = Tema.S(46);
            novo.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            novo.SetBounds(Tema.S(16), rodape.Height - novo.Height - Tema.S(12), rodape.Width - Tema.S(32), novo.Height);
            novo.Click += (s, e) => BeginInvoke(new Action(Novo));
            rodape.Controls.Add(novo);
        }

        int LarguraCartao { get { return Math.Max(Tema.S(200), lista.ClientSize.Width - lista.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth); } }

        void AjustarLarguras()
        {
            foreach (Control c in lista.Controls) c.Width = LarguraCartao;
        }

        static int Ordem(Lembrete l)
        {
            if (l.Status == Lembrete.TOCANDO) return 0;
            if (l.Status == Lembrete.SONECA) return 1;
            if (l.Status == Lembrete.AGENDADO) return 2;
            return 3;
        }

        public void Recarregar()
        {
            lista.SuspendLayout();
            foreach (Control c in lista.Controls.Cast<Control>().ToList()) c.Dispose();
            lista.Controls.Clear();

            var todos = Armazem.Dados.Lembretes
                .OrderBy(Ordem)
                .ThenBy(l => l.Ativo ? l.Proximo : l.CalcularProximo(DateTime.Now))
                .ToList();

            if (todos.Count == 0)
            {
                lista.Controls.Add(CartaoVazio());
            }
            else
            {
                foreach (var l in todos) lista.Controls.Add(Cartao(l));
            }
            lista.ResumeLayout();
            lista.Invalidate(true);
        }

        Panel CartaoBase(int altura)
        {
            var p = new Panel();
            p.BackColor = Color.White;
            p.Width = LarguraCartao;
            p.Height = altura;
            p.Margin = new Padding(0, 0, 0, Tema.S(8));
            p.Cursor = Cursors.Hand;
            Tema.Arredondar(p, Tema.S(14));
            return p;
        }

        Control CartaoVazio()
        {
            var p = CartaoBase(Tema.S(150));
            p.Cursor = Cursors.Default;
            p.BackColor = Color.White;
            var t = Tema.Texto("Nenhum lembrete ainda", Tema.FonteMedia(12f), Tema.TextoEscuro);
            t.Location = new Point(Tema.S(16), Tema.S(14));
            p.Controls.Add(t);
            var d = Tema.Texto(
                "Clique em \"+ Novo lembrete\", escreva o que você precisa fazer e escolha a hora.\n\n" +
                "Quando tocar, só existe SONECA. O alarme só para de vez quando você segura FEITO.",
                Tema.Fonte(10f), Tema.TextoCinza);
            d.AutoSize = false;
            d.SetBounds(Tema.S(16), Tema.S(44), p.Width - Tema.S(32), Tema.S(96));
            d.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            p.Controls.Add(d);
            return p;
        }

        Control Cartao(Lembrete l)
        {
            bool tocando = l.Status == Lembrete.TOCANDO;
            bool soneca = l.Status == Lembrete.SONECA;
            bool feito = !l.Ativo;
            bool temNota = !string.IsNullOrWhiteSpace(l.Nota);
            bool temBotao = tocando || soneca;

            int altura = Tema.S(temNota ? 78 : 62) + (temBotao ? Tema.S(48) : 0);
            var p = CartaoBase(altura);
            p.BackColor = feito ? Color.FromArgb(240, 240, 240) : Color.White;

            string horaGrande = tocando ? "⏰" : (feito ? l.HoraTexto : l.Proximo.ToString("HH:mm"));
            Color corHora = tocando ? Tema.Vermelho : soneca ? Color.FromArgb(230, 81, 0) : feito ? Tema.TextoCinza : Tema.Cor;
            var hora = Tema.Texto(horaGrande, tocando ? new Font("Segoe UI Emoji", 18f) : Tema.FonteLeve(20f), corHora);
            hora.AutoSize = false;
            hora.SetBounds(Tema.S(12), Tema.S(10), Tema.S(84), Tema.S(42));
            hora.TextAlign = ContentAlignment.MiddleLeft;
            p.Controls.Add(hora);

            int x = Tema.S(100);
            int w = p.Width - x - Tema.S(12);

            var titulo = Tema.Texto(l.TituloOuPadrao, Tema.FonteMedia(11.5f), feito ? Tema.TextoCinza : Tema.TextoEscuro);
            titulo.AutoSize = false;
            titulo.AutoEllipsis = true;
            titulo.SetBounds(x, Tema.S(10), w, Tema.S(24));
            titulo.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            p.Controls.Add(titulo);

            string sub;
            Color corSub = Tema.TextoCinza;
            if (tocando) { sub = "Tocando agora"; corSub = Tema.Vermelho; }
            else if (soneca) { sub = "Soneca · volta às " + l.Proximo.ToString("HH:mm"); corSub = Color.FromArgb(230, 81, 0); }
            else if (feito) sub = "Feito";
            else
            {
                sub = Lembrete.DiaTexto(l.Proximo) + " · " + l.RepeteTexto();
                int faltam = Lembrete.DiasAte(l.Proximo);
                if (faltam >= 2) sub += " · faltam " + faltam + " dias";
                if (l.QtdAvisos == 1) sub += " · 1 aviso";
                else if (l.QtdAvisos > 1) sub += " · " + l.QtdAvisos + " avisos";
            }
            var subt = Tema.Texto(sub, Tema.Fonte(9f), corSub);
            subt.AutoSize = false;
            subt.AutoEllipsis = true;
            subt.SetBounds(x, Tema.S(34), w, Tema.S(20));
            subt.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            p.Controls.Add(subt);

            if (temNota)
            {
                string umaLinha = l.Nota.Trim().Replace("\r", " ").Replace("\n", " ");
                var nota = Tema.Texto(umaLinha, Tema.Fonte(9f), Color.FromArgb(158, 158, 158));
                nota.AutoSize = false;
                nota.AutoEllipsis = true;
                nota.SetBounds(x, Tema.S(54), w, Tema.S(20));
                nota.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                p.Controls.Add(nota);
            }

            int id = l.Id;
            if (temBotao)
            {
                var b = Tema.Botao("Marcar como feito", Tema.Verde);
                b.Font = Tema.FonteMedia(10f);
                b.Height = Tema.S(38);
                b.SetBounds(Tema.S(12), altura - Tema.S(46), p.Width - Tema.S(24), Tema.S(38));
                b.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                b.Click += (s, e) => BeginInvoke(new Action(() => Motor.Instancia.AbrirAlarme(id)));
                p.Controls.Add(b);
            }

            EventHandler clique = (s, e) =>
            {
                var atual = Armazem.Buscar(id);
                if (atual == null) return;
                // abre depois de terminar o clique (a lista é refeita e o cartão clicado some)
                if (atual.Status == Lembrete.TOCANDO || atual.Status == Lembrete.SONECA)
                    BeginInvoke(new Action(() => Motor.Instancia.AbrirAlarme(id)));
                else
                    BeginInvoke(new Action(() => Editar(id)));
            };
            p.Click += clique;
            foreach (Control c in p.Controls)
            {
                if (!(c is Button)) { c.Click += clique; c.Cursor = Cursors.Hand; }
            }
            return p;
        }

        public void Novo()
        {
            using (var ed = new JanelaEditar(0))
            {
                ed.ShowDialog(this);
            }
            Recarregar();
        }

        void Editar(int id)
        {
            using (var ed = new JanelaEditar(id))
            {
                ed.ShowDialog(this);
            }
            Recarregar();
        }

        void AbrirAparencia()
        {
            using (var a = new JanelaAparencia())
            {
                a.ShowDialog(this);
            }
            MontarTopoERodape();
            Recarregar();
            Invalidate(true);
        }
    }
}
