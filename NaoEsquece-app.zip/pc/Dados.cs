using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace NaoEsquecePC
{
    /// <summary>Um lembrete: alarme + anotação (o "porquê" do alarme).</summary>
    [DataContract]
    public class Lembrete
    {
        public const string AGENDADO = "agendado", TOCANDO = "tocando", SONECA = "soneca", FEITO = "feito";

        /// <summary>Avisos antes, em minutos: 5, 15, 30 min, 1 h, 1 dia, 3 dias, 1 semana.</summary>
        public static readonly int[] AvisoOpcoes = { 5, 15, 30, 60, 1440, 4320, 10080 };

        // dias da semana: bit (1 << (int)DayOfWeek), domingo = 0 ... sábado = 6
        public const int TODOS_DIAS = 127, SEG_A_SEX = 62, FIM_DE_SEMANA = 65;

        [DataMember] public int Id;
        [DataMember] public string Titulo;
        [DataMember] public string Nota;
        [DataMember] public int Hora;
        [DataMember] public int Minuto;
        [DataMember] public DateTime Data;
        [DataMember] public int Dias;
        [DataMember] public int Avisos;
        [DataMember] public int SonecaMin;
        [DataMember] public string Status;
        [DataMember] public DateTime Proximo;
        [DataMember] public int Sonecas;
        [DataMember] public List<string> AvisosDados;

        public Lembrete()
        {
            Normalizar();
            Hora = 8;
            Data = DateTime.Today;
        }

        public void Normalizar()
        {
            if (Titulo == null) Titulo = "";
            if (Nota == null) Nota = "";
            if (Status == null) Status = AGENDADO;
            if (SonecaMin <= 0) SonecaMin = 5;
            if (AvisosDados == null) AvisosDados = new List<string>();
            if (Data == DateTime.MinValue) Data = DateTime.Today;
        }

        public bool Ativo { get { return Status != FEITO; } }
        public bool Repete { get { return Dias != 0; } }
        public string TituloOuPadrao { get { return string.IsNullOrWhiteSpace(Titulo) ? "Lembrete" : Titulo.Trim(); } }
        public string HoraTexto { get { return Hora.ToString("00") + ":" + Minuto.ToString("00"); } }
        public int QtdAvisos
        {
            get
            {
                int n = 0;
                for (int i = 0; i < AvisoOpcoes.Length; i++) if ((Avisos & (1 << i)) != 0) n++;
                return n;
            }
        }

        /// <summary>Próximo horário "normal" (sem soneca) depois de 'depois'.</summary>
        public DateTime CalcularProximo(DateTime depois)
        {
            if (!Repete) return Data.Date.AddHours(Hora).AddMinutes(Minuto);
            DateTime c = depois.Date.AddHours(Hora).AddMinutes(Minuto);
            if (c <= depois) c = c.AddDays(1);
            for (int i = 0; i < 8 && (Dias & (1 << (int)c.DayOfWeek)) == 0; i++) c = c.AddDays(1);
            return c;
        }

        /// <summary>Marca como feito: se repete, agenda a próxima vez; senão encerra.</summary>
        public void MarcarFeito()
        {
            Sonecas = 0;
            AvisosDados.Clear();
            if (Repete)
            {
                Status = AGENDADO;
                Proximo = CalcularProximo(DateTime.Now);
            }
            else
            {
                Status = FEITO;
            }
        }

        static readonly string[] NomesDias = { "Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb" };

        public string RepeteTexto()
        {
            if (!Repete) return "Uma vez";
            if (Dias == TODOS_DIAS) return "Todo dia";
            if (Dias == SEG_A_SEX) return "Seg a sex";
            if (Dias == FIM_DE_SEMANA) return "Fim de semana";
            var partes = new List<string>();
            int[] ordem = { 1, 2, 3, 4, 5, 6, 0 };
            foreach (int d in ordem) if ((Dias & (1 << d)) != 0) partes.Add(NomesDias[d]);
            return string.Join(", ", partes);
        }

        public static readonly CultureInfo BR = new CultureInfo("pt-BR");

        /// <summary>"hoje", "amanhã" ou "qua, 30/09".</summary>
        public static string DiaTexto(DateTime d)
        {
            if (d.Date == DateTime.Today) return "hoje";
            if (d.Date == DateTime.Today.AddDays(1)) return "amanhã";
            string fmt = d.Year == DateTime.Today.Year ? "ddd, dd/MM" : "ddd, dd/MM/yyyy";
            return d.ToString(fmt, BR);
        }

        public static int DiasAte(DateTime d)
        {
            return (int)(d.Date - DateTime.Today).TotalDays;
        }

        public static string AvisoNome(int min)
        {
            if (min >= 10080) return "1 semana";
            if (min >= 1440) return (min / 1440) + (min == 1440 ? " dia" : " dias");
            if (min >= 60) return (min / 60) + " h";
            return min + " min";
        }

        public static string FaltaTexto(TimeSpan t)
        {
            double min = Math.Max(1, Math.Round(t.TotalMinutes));
            if (min >= 1440)
            {
                long dias = (long)Math.Round(min / 1440.0);
                if (dias == 7) return "1 semana";
                return dias + (dias == 1 ? " dia" : " dias");
            }
            if (min >= 60 && ((long)min) % 60 == 0) return ((long)min / 60) + " h";
            return (long)min + " min";
        }
    }

    [DataContract]
    public class Config
    {
        [DataMember] public string Cor;
        [DataMember] public string Fundo;
        [DataMember] public string Papel;
        [DataMember] public int Escurecer;
        [DataMember] public string Som;
        [DataMember] public bool JaIniciou;
        [DataMember] public bool JaAvisouBandeja;

        public void Normalizar()
        {
            if (string.IsNullOrEmpty(Cor)) Cor = "#7C4DFF";
            if (string.IsNullOrEmpty(Fundo)) Fundo = "#F3E5F5";
            if (Escurecer <= 0 || Escurecer > 80) Escurecer = 30;
        }
    }

    [DataContract]
    public class Pacote
    {
        [DataMember] public string App;
        [DataMember] public List<Lembrete> Lembretes;
        [DataMember] public int ProximoId;
        [DataMember] public Config Config;

        public void Normalizar()
        {
            App = "NaoEsquecePC";
            if (Lembretes == null) Lembretes = new List<Lembrete>();
            foreach (var l in Lembretes) l.Normalizar();
            if (Config == null) Config = new Config();
            Config.Normalizar();
            int maior = Lembretes.Count == 0 ? 0 : Lembretes.Max(x => x.Id);
            if (ProximoId <= maior) ProximoId = maior + 1;
            if (ProximoId < 1) ProximoId = 1;
        }
    }

    /// <summary>Guarda tudo em %AppData%\NaoEsquece\dados.json.</summary>
    public static class Armazem
    {
        public static Pacote Dados;

        public static string Pasta
        {
            get
            {
                string p = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NaoEsquece");
                Directory.CreateDirectory(p);
                return p;
            }
        }

        static string Arquivo { get { return Path.Combine(Pasta, "dados.json"); } }

        static DataContractJsonSerializer Serializador()
        {
            var cfg = new DataContractJsonSerializerSettings();
            cfg.DateTimeFormat = new DateTimeFormat("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture);
            return new DataContractJsonSerializer(typeof(Pacote), cfg);
        }

        public static string Serializar(Pacote p)
        {
            using (var ms = new MemoryStream())
            {
                Serializador().WriteObject(ms, p);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        public static Pacote Desserializar(string json)
        {
            using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                var p = (Pacote)Serializador().ReadObject(ms);
                if (p == null) throw new InvalidDataException("arquivo vazio");
                p.Normalizar();
                return p;
            }
        }

        public static void Carregar()
        {
            try
            {
                if (File.Exists(Arquivo))
                {
                    Dados = Desserializar(File.ReadAllText(Arquivo, Encoding.UTF8));
                    return;
                }
            }
            catch
            {
                try { File.Copy(Arquivo, Arquivo + ".com-erro", true); } catch { }
            }
            Dados = new Pacote();
            Dados.Normalizar();
        }

        public static void Salvar()
        {
            try
            {
                string tmp = Arquivo + ".tmp";
                File.WriteAllText(tmp, Serializar(Dados), Encoding.UTF8);
                File.Copy(tmp, Arquivo, true);
                File.Delete(tmp);
            }
            catch
            {
                // disco cheio ou arquivo bloqueado: tenta de novo na próxima alteração
            }
        }

        public static Lembrete Buscar(int id)
        {
            return Dados.Lembretes.FirstOrDefault(x => x.Id == id);
        }

        public static void Adicionar(Lembrete l)
        {
            l.Id = Dados.ProximoId++;
            Dados.Lembretes.Add(l);
            Salvar();
        }

        public static void Remover(int id)
        {
            Dados.Lembretes.RemoveAll(x => x.Id == id);
            Salvar();
        }
    }
}
