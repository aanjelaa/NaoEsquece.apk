using System;
using System.Drawing;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    /// <summary>Criar ou editar um lembrete (alarme + bloco de notas).</summary>
    public class JanelaEditar : Form
    {
        readonly Lembrete r;
        readonly bool novo;
        readonly TextBox titulo, nota;
        readonly DateTimePicker hora, data;
        readonly Label rotuloData;
        readonly CheckBox[] dias = new CheckBox[7];
        readonly CheckBox[] avisos = new CheckBox[Lembrete.AvisoOpcoes.Length];
        readonly ComboBox soneca;
        readonly Label resumo;
        bool atualizando;

        // ordem na tela: seg, ter, qua, qui, sex, sáb, dom
        static readonly DayOfWeek[] OrdemDias =
        {
            DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday,
            DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday
        };
        static readonly string[] Letras = { "S", "T", "Q", "Q", "S", "S", "D" };
        static readonly int[] Sonecas = { 1, 3, 5, 10, 15 };

        public JanelaEditar(int id)
        {
            var existente = id > 0 ? Armazem.Buscar(id) : null;
            novo = existente == null;
            if (novo)
            {
                r = new Lembrete();
                DateTime daqui = DateTime.Now.AddMinutes(30);
                r.Hora = daqui.Hour;
                r.Minuto = daqui.Minute;
                r.Data = daqui.Date;
            }
            else
            {
                r = existente;
            }

            Text = novo ? "Novo lembrete" : "Editar lembrete";
            if (Tema.IconeApp != null) Icon = Tema.IconeApp;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.White;
            Font = Tema.Fonte(10f);
            int m = Tema.S(20);
            int largura = Tema.S(400);
            ClientSize = new Size(largura + 2 * m, Tema.S(700));
            int y = Tema.S(14);

            // Hora grande
            hora = new DateTimePicker();
            hora.Format = DateTimePickerFormat.Custom;
            hora.CustomFormat = "HH:mm";
            hora.ShowUpDown = true;
            hora.Font = Tema.FonteLeve(26f);
            hora.Value = DateTime.Today.AddHours(r.Hora).AddMinutes(r.Minuto);
            hora.SetBounds(m + (largura - Tema.S(150)) / 2, y, Tema.S(150), Tema.S(52));
            Controls.Add(hora);
            y += Tema.S(58);

            resumo = Tema.Texto("", Tema.Fonte(9f), Tema.TextoCinza);
            resumo.AutoSize = false;
            resumo.TextAlign = ContentAlignment.MiddleCenter;
            resumo.SetBounds(m, y, largura, Tema.S(20));
            Controls.Add(resumo);
            y += Tema.S(30);

            // O que é + anotação
            y = Rotulo("O que é", m, y);
            titulo = new TextBox();
            titulo.Font = Tema.Fonte(12f);
            titulo.Text = r.Titulo;
            titulo.SetBounds(m, y, largura, Tema.S(30));
            Controls.Add(titulo);
            y += Tema.S(40);

            y = Rotulo("Anotação · por que esse alarme existe", m, y);
            nota = new TextBox();
            nota.Multiline = true;
            nota.AcceptsReturn = true;
            nota.ScrollBars = ScrollBars.Vertical;
            nota.Font = Tema.Fonte(10.5f);
            nota.Text = (r.Nota ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n");
            nota.SetBounds(m, y, largura, Tema.S(92));
            Controls.Add(nota);
            y += Tema.S(104);

            // Repetir
            y = Rotulo("Repetir nos dias", m, y);
            int wChip = (largura - 6 * Tema.S(6)) / 7;
            for (int i = 0; i < 7; i++)
            {
                var c = Tema.Chip(Letras[i]);
                c.SetBounds(m + i * (wChip + Tema.S(6)), y, wChip, Tema.S(34));
                c.Checked = (r.Dias & (1 << (int)OrdemDias[i])) != 0;
                c.CheckedChanged += (s, e) => Atualizar();
                dias[i] = c;
                Controls.Add(c);
            }
            y += Tema.S(40);

            int xAtalho = m;
            xAtalho = Atalho("Todo dia", Lembrete.TODOS_DIAS, xAtalho, y);
            xAtalho = Atalho("Seg a sex", Lembrete.SEG_A_SEX, xAtalho, y);
            Atalho("Nenhum (uma vez só)", 0, xAtalho, y);
            y += Tema.S(28);

            rotuloData = Tema.Rotulo("Dia");
            rotuloData.Location = new Point(m, y);
            Controls.Add(rotuloData);
            data = new DateTimePicker();
            data.Format = DateTimePickerFormat.Long;
            data.Font = Tema.Fonte(10.5f);
            data.Value = r.Data < DateTime.Today.AddYears(-1) ? DateTime.Today : r.Data;
            data.SetBounds(m, y + Tema.S(18), largura, Tema.S(30));
            data.ValueChanged += (s, e) => Atualizar();
            Controls.Add(data);
            y += Tema.S(58);

            // Avisar antes
            y = Rotulo("Avisar antes · pode marcar vários", m, y);
            int w4 = (largura - 3 * Tema.S(6)) / 4;
            for (int i = 0; i < avisos.Length; i++)
            {
                var c = Tema.Chip(Lembrete.AvisoNome(Lembrete.AvisoOpcoes[i]));
                int linha = i < 4 ? 0 : 1;
                int col = i < 4 ? i : i - 4;
                c.SetBounds(m + col * (w4 + Tema.S(6)), y + linha * Tema.S(40), w4, Tema.S(34));
                c.Checked = (r.Avisos & (1 << i)) != 0;
                avisos[i] = c;
                Controls.Add(c);
            }
            y += Tema.S(86);

            // Soneca
            y = Rotulo("Soneca", m, y);
            soneca = new ComboBox();
            soneca.DropDownStyle = ComboBoxStyle.DropDownList;
            soneca.Font = Tema.Fonte(10.5f);
            int sel = 2;
            for (int i = 0; i < Sonecas.Length; i++)
            {
                soneca.Items.Add(Sonecas[i] + " minutos");
                if (Sonecas[i] == r.SonecaMin) sel = i;
            }
            soneca.SelectedIndex = sel;
            soneca.SetBounds(m, y, Tema.S(160), Tema.S(30));
            Controls.Add(soneca);

            // Botões
            int yBotoes = ClientSize.Height - Tema.S(62);
            var salvar = Tema.Botao("Salvar", Tema.Cor);
            salvar.SetBounds(m + largura - Tema.S(170), yBotoes, Tema.S(170), Tema.S(42));
            salvar.Click += (s, e) => Salvar();
            Controls.Add(salvar);

            var cancelar = Tema.Botao("Cancelar", Color.FromArgb(238, 238, 238));
            cancelar.SetBounds(m + largura - Tema.S(170) - Tema.S(120), yBotoes, Tema.S(110), Tema.S(42));
            cancelar.Click += (s, e) => Close();
            Controls.Add(cancelar);

            if (!novo)
            {
                var apagar = new LinkLabel();
                apagar.Text = "Apagar";
                apagar.Font = Tema.FonteMedia(10f);
                apagar.LinkColor = Tema.Vermelho;
                apagar.ActiveLinkColor = Tema.Vermelho;
                apagar.LinkBehavior = LinkBehavior.HoverUnderline;
                apagar.AutoSize = true;
                apagar.Location = new Point(m, yBotoes + Tema.S(11));
                apagar.LinkClicked += (s, e) => Apagar();
                Controls.Add(apagar);
            }

            hora.ValueChanged += (s, e) => Atualizar();
            AcceptButton = null;
            CancelButton = cancelar;
            Atualizar();
        }

        int Rotulo(string texto, int x, int y)
        {
            var l = Tema.Rotulo(texto);
            l.Location = new Point(x, y);
            Controls.Add(l);
            return y + Tema.S(18);
        }

        int Atalho(string texto, int mask, int x, int y)
        {
            var a = new LinkLabel();
            a.Text = texto;
            a.Font = Tema.Fonte(9f);
            a.LinkColor = Tema.TextoCinza;
            a.ActiveLinkColor = Tema.Cor;
            a.LinkBehavior = LinkBehavior.HoverUnderline;
            a.AutoSize = true;
            a.Location = new Point(x, y);
            a.LinkClicked += (s, e) =>
            {
                atualizando = true;
                for (int i = 0; i < 7; i++) dias[i].Checked = (mask & (1 << (int)OrdemDias[i])) != 0;
                atualizando = false;
                Atualizar();
            };
            Controls.Add(a);
            return x + TextRenderer.MeasureText(texto, a.Font).Width + Tema.S(18);
        }

        int DiasMarcados()
        {
            int mask = 0;
            for (int i = 0; i < 7; i++) if (dias[i].Checked) mask |= 1 << (int)OrdemDias[i];
            return mask;
        }

        void Atualizar()
        {
            if (atualizando || resumo == null || data == null) return;
            int mask = DiasMarcados();
            bool umaVez = mask == 0;
            data.Visible = umaVez;
            rotuloData.Visible = umaVez;

            var tmp = new Lembrete();
            tmp.Dias = mask;
            string res = tmp.RepeteTexto();
            if (umaVez)
            {
                res += " · " + data.Value.ToString("dddd, dd/MM/yyyy", Lembrete.BR);
                int faltam = Lembrete.DiasAte(data.Value);
                if (faltam >= 2) res += " · faltam " + faltam + " dias";
            }
            resumo.Text = res;
        }

        void Salvar()
        {
            bool tocandoAgora = r.Status == Lembrete.TOCANDO;
            r.Titulo = string.IsNullOrWhiteSpace(titulo.Text) ? "Lembrete" : titulo.Text.Trim();
            r.Nota = nota.Text;

            if (tocandoAgora)
            {
                // Está tocando: só guarda o texto, o alarme continua até marcar como feito
                Armazem.Salvar();
                Motor.Instancia.AvisarMudanca();
                Close();
                return;
            }

            r.Hora = hora.Value.Hour;
            r.Minuto = hora.Value.Minute;
            r.Dias = DiasMarcados();
            r.Data = data.Value.Date;
            r.SonecaMin = Sonecas[Math.Max(0, soneca.SelectedIndex)];
            int mask = 0;
            for (int i = 0; i < avisos.Length; i++) if (avisos[i].Checked) mask |= 1 << i;
            r.Avisos = mask;

            DateTime agora = DateTime.Now;
            if (!r.Repete)
            {
                DateTime quando = r.CalcularProximo(agora);
                if (quando <= agora)
                {
                    if (r.Data == DateTime.Today)
                    {
                        r.Data = r.Data.AddDays(1);
                    }
                    else
                    {
                        MessageBox.Show(this, "Esse dia e horário já passaram. Escolha outro.", "Não Esquece",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
            r.Status = Lembrete.AGENDADO;
            r.Sonecas = 0;
            r.AvisosDados.Clear();
            r.Proximo = r.CalcularProximo(agora);

            if (novo) Armazem.Adicionar(r);
            else Armazem.Salvar();
            Motor.Instancia.AvisarMudanca();
            DialogResult = DialogResult.OK;
            Close();
        }

        void Apagar()
        {
            var resp = MessageBox.Show(this, "Apagar \"" + r.TituloOuPadrao + "\"?", "Não Esquece",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (resp != DialogResult.Yes) return;
            Armazem.Remover(r.Id);
            Motor.Instancia.FecharAlarme(r.Id);
            Motor.Instancia.AvisarMudanca();
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
