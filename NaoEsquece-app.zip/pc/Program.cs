using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace NaoEsquecePC
{
    static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main(string[] args)
        {
            bool primeira;
            using (var unico = new Mutex(true, "NaoEsquecePC_unico", out primeira))
            {
                if (!primeira)
                {
                    // Já está aberto: só pede para mostrar a janela
                    try { EventWaitHandle.OpenExisting("NaoEsquecePC_abrir").Set(); } catch { }
                    return;
                }

                try { SetProcessDPIAware(); } catch { }
                var br = new CultureInfo("pt-BR");
                Thread.CurrentThread.CurrentCulture = br;
                Thread.CurrentThread.CurrentUICulture = br;

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += (s, e) =>
                    MessageBox.Show("Ops, algo deu errado:\n\n" + e.Exception.Message, "Não Esquece");

                Tema.Iniciar();
                Armazem.Carregar();
                bool naBandeja = Array.IndexOf(args, "--bandeja") >= 0;
                Application.Run(new Motor(!naBandeja));
                GC.KeepAlive(unico);
            }
        }
    }
}
