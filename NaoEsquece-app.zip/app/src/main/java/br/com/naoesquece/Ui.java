package br.com.naoesquece;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

/** Aparência: cores, papel de parede e peças de tela reaproveitadas. */
public class Ui {
    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    public static final int[] CORES = {
            0xFF7C4DFF, 0xFFE91E63, 0xFFF44336, 0xFFFF9800, 0xFF4CAF50,
            0xFF009688, 0xFF2196F3, 0xFF3F51B5, 0xFF795548, 0xFF424242
    };
    public static final int[] FUNDOS = {
            0xFFF3E5F5, 0xFFFCE4EC, 0xFFFFF3E0, 0xFFFFFDE7, 0xFFE8F5E9,
            0xFFE0F2F1, 0xFFE3F2FD, 0xFFECEFF1, 0xFF212121, 0xFF1A237E
    };

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("aparencia", Context.MODE_PRIVATE);
    }

    public static int cor(Context c) { return prefs(c).getInt("cor", CORES[0]); }
    public static int fundo(Context c) { return prefs(c).getInt("fundo", FUNDOS[0]); }
    public static int escurecer(Context c) { return prefs(c).getInt("escurecer", 30); }
    public static String som(Context c) { return prefs(c).getString("som", null); }

    public static File papelArquivo(Context c) { return new File(c.getFilesDir(), "papel.jpg"); }
    public static boolean temPapel(Context c) { return papelArquivo(c).exists(); }

    private static Bitmap cache;
    private static long cacheMarca = -1;

    static Bitmap papel(Context c) {
        File f = papelArquivo(c);
        if (!f.exists()) return null;
        long marca = f.lastModified() ^ f.length();
        if (cache != null && cacheMarca == marca) return cache;
        cache = BitmapFactory.decodeFile(f.getAbsolutePath());
        cacheMarca = marca;
        return cache;
    }

    public static void limparCache() {
        cache = null;
        cacheMarca = -1;
    }

    static double luz(int cor) {
        return (0.299 * Color.red(cor) + 0.587 * Color.green(cor) + 0.114 * Color.blue(cor)) / 255.0;
    }

    public static boolean fundoEscuro(Context c) {
        return temPapel(c) || luz(fundo(c)) < 0.5;
    }

    /** Cor do texto que fica direto sobre o fundo (fora dos cartões). */
    public static int textoFundo(Context c) {
        return fundoEscuro(c) ? Color.WHITE : 0xFF212121;
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    /** Coloca o papel de parede (ou a cor de fundo) atrás do conteúdo da tela. */
    public static void moldura(Activity a, View conteudo) {
        FrameLayout root = new FrameLayout(a);
        Bitmap bmp = papel(a);
        if (bmp != null) {
            ImageView iv = new ImageView(a);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(bmp);
            root.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
            View escuro = new View(a);
            escuro.setBackgroundColor(Color.argb(escurecer(a) * 255 / 100, 0, 0, 0));
            root.addView(escuro, new FrameLayout.LayoutParams(MATCH, MATCH));
        } else {
            root.setBackgroundColor(fundo(a));
        }
        root.addView(conteudo, new FrameLayout.LayoutParams(MATCH, MATCH));
        a.getWindow().setStatusBarColor(cor(a));
        a.setContentView(root);
    }

    public static GradientDrawable redondo(int cor, float raio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cor);
        g.setCornerRadius(raio);
        return g;
    }

    public static LinearLayout cartao(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(redondo(0xF2FFFFFF, dp(c, 18)));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        l.setElevation(dp(c, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, dp(c, 12));
        l.setLayoutParams(lp);
        return l;
    }

    public static Button botao(Context c, String texto, int cor) {
        Button b = new Button(c);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextColor(luz(cor) > 0.7 ? 0xFF212121 : Color.WHITE);
        b.setTextSize(17);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(redondo(cor, dp(c, 28)));
        b.setStateListAnimator(null);
        b.setPadding(dp(c, 20), dp(c, 12), dp(c, 20), dp(c, 12));
        b.setMinHeight(dp(c, 52));
        b.setGravity(Gravity.CENTER);
        return b;
    }

    public static TextView texto(Context c, String t, float sp, int cor, boolean negrito) {
        TextView tv = new TextView(c);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(cor);
        if (negrito) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    public static LinearLayout.LayoutParams linha(Context c, int topoDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, dp(c, topoDp), 0, 0);
        return lp;
    }
}
