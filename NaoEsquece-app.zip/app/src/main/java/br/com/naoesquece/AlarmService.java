package br.com.naoesquece;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Toca o alarme e só para com SONECA ou FEITO.
 * Se ninguém mexer por 3 minutos, entra em soneca sozinho e volta a tocar depois.
 */
public class AlarmService extends Service {
    public static final String TOCAR = "tocar", SONECA = "soneca", FEITO = "feito", REEXIBIR = "reexibir";
    public static final String MUDOU = "br.com.naoesquece.MUDOU";
    static final String CANAL = "alarme_v1", CANAL_INFO = "info_v1";
    static final int NOTIF_ID = 777;
    static final long SONECA_AUTOMATICA_MS = 3 * 60 * 1000L;

    private final List<Integer> tocando = new ArrayList<>();
    private final Map<Integer, Runnable> automaticos = new HashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        criarCanais();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            entrarPrimeiroPlano(notificacaoInfo());
            finalizarSeVazio();
            return START_NOT_STICKY;
        }
        int id = intent.getIntExtra("id", -1);
        String acao = intent.getAction();

        // O Android exige mostrar a notificação logo no começo
        Reminder atual = tocando.isEmpty() ? null : Store.pegar(this, tocando.get(tocando.size() - 1));
        if (TOCAR.equals(acao)) {
            Reminder r = Store.pegar(this, id);
            entrarPrimeiroPlano(r != null ? notificacao(r) : notificacaoInfo());
        } else {
            entrarPrimeiroPlano(atual != null ? notificacao(atual) : notificacaoInfo());
        }

        if (TOCAR.equals(acao)) tocar(id);
        else if (SONECA.equals(acao)) soneca(id);
        else if (FEITO.equals(acao)) feito(id);
        else if (REEXIBIR.equals(acao)) atualizar();
        else finalizarSeVazio();
        return START_NOT_STICKY;
    }

    private void tocar(int id) {
        Reminder r = Store.pegar(this, id);
        if (r == null || !r.ativo()) {
            atualizar();
            return;
        }
        tocando.remove(Integer.valueOf(id));
        tocando.add(id);
        r.status = Reminder.TOCANDO;
        // Alarme reserva: se o app for fechado à força, volta a tocar em alguns minutos
        r.proximo = System.currentTimeMillis() + SONECA_AUTOMATICA_MS + 60_000;
        Store.salvar(this, r);
        Scheduler.agendar(this, r);

        cancelarAutomatico(id);
        Runnable auto = () -> soneca(id);
        automaticos.put(id, auto);
        handler.postDelayed(auto, SONECA_AUTOMATICA_MS);

        iniciarSom();
        abrirTelaDoAlarme(id);
        atualizar();
    }

    private void soneca(int id) {
        cancelarAutomatico(id);
        tocando.remove(Integer.valueOf(id));
        Reminder r = Store.pegar(this, id);
        if (r != null && r.ativo()) {
            r.status = Reminder.SONECA;
            r.sonecas++;
            r.proximo = System.currentTimeMillis() + r.sonecaMin * 60_000L;
            Store.salvar(this, r);
            Scheduler.agendar(this, r);
        }
        atualizar();
    }

    private void feito(int id) {
        cancelarAutomatico(id);
        tocando.remove(Integer.valueOf(id));
        Reminder r = Store.pegar(this, id);
        if (r != null) Scheduler.marcarFeito(this, r);
        atualizar();
    }

    private void atualizar() {
        sendBroadcast(new Intent(MUDOU).setPackage(getPackageName()));
        if (tocando.isEmpty()) {
            finalizarSeVazio();
            return;
        }
        Reminder r = Store.pegar(this, tocando.get(tocando.size() - 1));
        if (r != null) {
            getSystemService(NotificationManager.class).notify(NOTIF_ID, notificacao(r));
        }
    }

    private void finalizarSeVazio() {
        if (!tocando.isEmpty()) return;
        pararSom();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void cancelarAutomatico(int id) {
        Runnable r = automaticos.remove(id);
        if (r != null) handler.removeCallbacks(r);
    }

    private void abrirTelaDoAlarme(int id) {
        try {
            Intent i = new Intent(this, AlarmActivity.class).putExtra("id", id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
            // Em alguns Androids só abre pela notificação; tudo bem.
        }
    }

    // ---------- som e vibração ----------

    private void iniciarSom() {
        if (wakeLock == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "naoesquece:alarme");
            wakeLock.acquire(10 * 60 * 1000L);
        }
        if (player == null) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            for (Uri uri : sonsParaTentar()) {
                if (uri == null) continue;
                try {
                    MediaPlayer mp = new MediaPlayer();
                    mp.setAudioAttributes(attrs);
                    mp.setDataSource(this, uri);
                    mp.setLooping(true);
                    mp.prepare();
                    mp.start();
                    player = mp;
                    break;
                } catch (Exception e) {
                    player = null;
                }
            }
        }
        if (vibrator == null) {
            vibrator = getSystemService(Vibrator.class);
            if (vibrator != null && vibrator.hasVibrator()) {
                AudioAttributes va = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM).build();
                vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 900, 700}, 0), va);
            }
        }
    }

    private Uri[] sonsParaTentar() {
        String escolhido = Ui.som(this);
        return new Uri[]{
                escolhido != null ? Uri.parse(escolhido) : null,
                RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM),
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        };
    }

    private void pararSom() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
            vibrator = null;
        }
        if (wakeLock != null) {
            if (wakeLock.isHeld()) wakeLock.release();
            wakeLock = null;
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        pararSom();
        super.onDestroy();
    }

    // ---------- notificações ----------

    private void criarCanais() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel c = new NotificationChannel(CANAL, "Alarmes", NotificationManager.IMPORTANCE_HIGH);
        c.setDescription("Alarmes que só param quando você marca como feito");
        c.setSound(null, null);
        c.enableVibration(false);
        c.setBypassDnd(true);
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(c);
        NotificationChannel info = new NotificationChannel(CANAL_INFO, "Avisos", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(info);
    }

    private void entrarPrimeiroPlano(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification notificacaoInfo() {
        return new Notification.Builder(this, CANAL_INFO)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Não Esquece")
                .setContentText("Atualizando alarmes…")
                .build();
    }

    private Notification notificacao(Reminder r) {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent abrir = new Intent(this, AlarmActivity.class).putExtra("id", r.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent abrirPi = PendingIntent.getActivity(this, r.id, abrir, flags);

        Intent sonecaI = new Intent(this, AlarmService.class).setAction(SONECA).putExtra("id", r.id);
        PendingIntent sonecaPi = PendingIntent.getForegroundService(this, 10000 + r.id, sonecaI, flags);

        Intent reexibir = new Intent(this, AlarmService.class).setAction(REEXIBIR).putExtra("id", r.id);
        PendingIntent reexibirPi = PendingIntent.getForegroundService(this, 20000 + r.id, reexibir, flags);

        String texto = r.nota == null || r.nota.trim().isEmpty()
                ? "Toque aqui para abrir e marcar como feito"
                : r.nota.trim();
        int outros = tocando.size() - 1;
        if (outros > 0) texto = "(+" + outros + " outro(s) tocando)\n" + texto;

        return new Notification.Builder(this, CANAL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("⏰ " + r.tituloOuPadrao())
                .setContentText(texto)
                .setStyle(new Notification.BigTextStyle().bigText(texto))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setColor(Ui.cor(this))
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(abrirPi)
                .setFullScreenIntent(abrirPi, true)
                .setDeleteIntent(reexibirPi)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notif),
                        "😴 Soneca " + r.sonecaMin + " min", sonecaPi).build())
                .build();
    }
}
