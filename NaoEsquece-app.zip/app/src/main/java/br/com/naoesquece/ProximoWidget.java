package br.com.naoesquece;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Widget da tela inicial: mostra o próximo lembrete. */
public class ProximoWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        atualizar(c);
    }

    public static void atualizar(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        if (m == null) return;
        int[] ids = m.getAppWidgetIds(new ComponentName(c, ProximoWidget.class));
        if (ids == null || ids.length == 0) return;

        Reminder prox = null;
        for (Reminder r : Store.todos(c)) {
            if (!r.ativo()) continue;
            if (Reminder.TOCANDO.equals(r.status)) {
                prox = r;
                break;
            }
            if (prox == null || r.proximo < prox.proximo) prox = r;
        }

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        if (prox == null) {
            v.setTextViewText(R.id.w_hora, "—");
            v.setTextViewText(R.id.w_rotulo, "Nenhum lembrete");
            v.setTextViewText(R.id.w_titulo, "Toque para criar");
            v.setTextViewText(R.id.w_dia, "");
        } else {
            boolean tocando = Reminder.TOCANDO.equals(prox.status);
            boolean soneca = Reminder.SONECA.equals(prox.status);
            v.setTextViewText(R.id.w_hora, tocando ? "⏰" : Reminder.so_hora(prox.proximo));
            v.setTextViewText(R.id.w_rotulo, tocando ? "TOCANDO AGORA" : soneca ? "Soneca" : "Próximo");
            v.setTextViewText(R.id.w_titulo, prox.tituloOuPadrao());
            v.setTextViewText(R.id.w_dia, tocando ? "Toque para ver" : Reminder.diaTexto(prox.proximo));
        }
        v.setTextColor(R.id.w_hora, Ui.cor(c));

        PendingIntent abrir = PendingIntent.getActivity(c, 60000,
                new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.w_raiz, abrir);
        m.updateAppWidget(ids, v);
    }
}
