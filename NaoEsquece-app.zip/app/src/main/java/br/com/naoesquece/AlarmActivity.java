package br.com.naoesquece;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Tela que aparece quando o alarme toca: mostra a anotação e só oferece Soneca ou Feito. */
public class AlarmActivity extends Activity {
    private static final long SEGURAR_MS = 1500;
    private int id;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private android.view.View barra;
    private FrameLayout caixaFeito;
    private long inicioToque;
    private boolean concluido;

    private final BroadcastReceiver mudou = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            Reminder r = Store.pegar(AlarmActivity.this, id);
            if (r == null || !r.ativo() || Reminder.AGENDADO.equals(r.status)) finish();
            else montar();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        id = getIntent().getIntExtra("id", -1);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        id = intent.getIntExtra("id", id);
        montar();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(AlarmService.MUDOU);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(mudou, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(mudou, f);
        montar();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(mudou);
        } catch (Exception ignored) {
        }
    }

    private void montar() {
        Reminder r = Store.pegar(this, id);
        if (r == null || !r.ativo()) {
            finish();
            return;
        }
        concluido = false;
        boolean tocandoAgora = Reminder.TOCANDO.equals(r.status);
        int txt = Ui.textoFundo(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        tela.setPadding(p, Ui.dp(this, 36), p, p);

        TextView sino = Ui.texto(this, tocandoAgora ? "⏰" : "😴", 44, txt, false);
        sino.setGravity(Gravity.CENTER);
        tela.addView(sino);

        TextView hora = Ui.texto(this, Reminder.so_hora(System.currentTimeMillis()), 20, txt, false);
        hora.setGravity(Gravity.CENTER);
        tela.addView(hora);

        TextView titulo = Ui.texto(this, r.tituloOuPadrao(), 26, txt, true);
        titulo.setGravity(Gravity.CENTER);
        tela.addView(titulo, Ui.linha(this, 8));

        if (r.sonecas > 0) {
            TextView s = Ui.texto(this, "Você já apertou soneca " + r.sonecas + "x", 15, txt, false);
            s.setGravity(Gravity.CENTER);
            tela.addView(s, Ui.linha(this, 4));
        }

        // Anotação: o porquê do alarme
        LinearLayout cartao = Ui.cartao(this);
        cartao.addView(Ui.texto(this, "📝 Por que está tocando", 15, 0xFF555555, true));
        String nota = r.nota == null || r.nota.trim().isEmpty() ? "(sem anotação)" : r.nota.trim();
        TextView tvNota = Ui.texto(this, nota, 20, 0xFF212121, false);
        tvNota.setTextIsSelectable(true);
        cartao.addView(tvNota, Ui.linha(this, 6));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(cartao);
        LinearLayout.LayoutParams lpScroll = new LinearLayout.LayoutParams(Ui.MATCH, 0, 1);
        lpScroll.setMargins(0, Ui.dp(this, 16), 0, 0);
        tela.addView(scroll, lpScroll);

        if (tocandoAgora) {
            Button soneca = Ui.botao(this, "😴 Soneca " + r.sonecaMin + " min", 0xFFFF8F00);
            soneca.setTextSize(18);
            soneca.setMinHeight(Ui.dp(this, 56));
            soneca.setOnClickListener(v -> {
                startForegroundService(new Intent(this, AlarmService.class)
                        .setAction(AlarmService.SONECA).putExtra("id", id));
                finish();
            });
            tela.addView(soneca, Ui.linha(this, 12));
        } else {
            TextView info = Ui.texto(this, "Em soneca — volta a tocar às " + Reminder.so_hora(r.proximo),
                    16, txt, true);
            info.setGravity(Gravity.CENTER);
            tela.addView(info, Ui.linha(this, 12));
        }

        // Botão FEITO: precisa segurar, para não desligar no automático
        FrameLayout feitoBox = new FrameLayout(this);
        barra = new android.view.View(this);
        barra.setBackgroundColor(0xFF1B5E20);
        feitoBox.addView(barra, new FrameLayout.LayoutParams(0, Ui.MATCH, Gravity.START));
        caixaFeito = feitoBox;
        TextView rotulo = Ui.texto(this, "Segure para marcar FEITO", 17, Color.WHITE, true);
        rotulo.setGravity(Gravity.CENTER);
        feitoBox.addView(rotulo, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        feitoBox.setClipToOutline(true);
        feitoBox.setBackground(Ui.redondo(0xFF66BB6A, Ui.dp(this, 28)));
        feitoBox.setOnTouchListener((v, ev) -> {
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    inicioToque = System.currentTimeMillis();
                    handler.post(avancar);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(avancar);
                    if (!concluido) {
                        definirProgresso(0);
                        if (ev.getAction() == MotionEvent.ACTION_UP) {
                            Toast.makeText(this, "Segure o botão até a barra encher", Toast.LENGTH_SHORT).show();
                        }
                    }
                    return true;
            }
            return true;
        });
        LinearLayout.LayoutParams lpFeito = new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 56));
        lpFeito.setMargins(0, Ui.dp(this, 12), 0, 0);
        tela.addView(feitoBox, lpFeito);

        Ui.moldura(this, tela);
    }

    private final Runnable avancar = new Runnable() {
        @Override
        public void run() {
            long passou = System.currentTimeMillis() - inicioToque;
            int pct = (int) Math.min(100, passou * 100 / SEGURAR_MS);
            definirProgresso(pct);
            if (pct >= 100) {
                if (!concluido) {
                    concluido = true;
                    startForegroundService(new Intent(AlarmActivity.this, AlarmService.class)
                            .setAction(AlarmService.FEITO).putExtra("id", id));
                    Toast.makeText(AlarmActivity.this, "Feito! 🎉", Toast.LENGTH_SHORT).show();
                    finish();
                }
            } else {
                handler.postDelayed(this, 30);
            }
        }
    };

    private void definirProgresso(int pct) {
        if (barra == null || caixaFeito == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) barra.getLayoutParams();
        lp.width = caixaFeito.getWidth() * pct / 100;
        barra.setLayoutParams(lp);
    }

    @Override
    public void onBackPressed() {
        Reminder r = Store.pegar(this, id);
        if (r != null && Reminder.TOCANDO.equals(r.status)) {
            Toast.makeText(this, "Escolha Soneca ou segure Feito", Toast.LENGTH_SHORT).show();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
