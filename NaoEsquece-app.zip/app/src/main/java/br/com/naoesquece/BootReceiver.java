package br.com.naoesquece;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Reagenda os alarmes quando o celular liga, o app atualiza ou a hora muda. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        boolean reiniciou = !Intent.ACTION_TIME_CHANGED.equals(a) && !Intent.ACTION_TIMEZONE_CHANGED.equals(a);
        Scheduler.reagendarTodos(c, reiniciou);
    }
}
