package br.com.naoesquece;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Backup dos lembretes e anotações num arquivo escolhido pela usuária
 * (normalmente no Google Drive). Toda alteração é gravada sozinha no arquivo.
 */
public class Backup {
    private static Handler fila;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("backup", Context.MODE_PRIVATE);
    }

    public static Uri arquivo(Context c) {
        String s = prefs(c).getString("uri", null);
        return s == null ? null : Uri.parse(s);
    }

    public static String nomeArquivo(Context c) {
        return prefs(c).getString("nome", "NaoEsquece-backup.json");
    }

    public static long ultimo(Context c) { return prefs(c).getLong("ultimo", 0); }
    public static boolean deuErro(Context c) { return prefs(c).getBoolean("erro", false); }

    public static void ativar(Context c, Uri uri, String nome) {
        prefs(c).edit().putString("uri", uri.toString()).putString("nome", nome)
                .putBoolean("erro", false).apply();
    }

    public static void desativar(Context c) {
        prefs(c).edit().remove("uri").remove("ultimo").remove("erro").apply();
    }

    /** Pede para salvar daqui a pouco (junta várias alterações seguidas numa gravação só). */
    public static synchronized void agendar(Context ctx) {
        final Context c = ctx.getApplicationContext();
        if (arquivo(c) == null) return;
        if (fila == null) {
            HandlerThread t = new HandlerThread("backup");
            t.start();
            fila = new Handler(t.getLooper());
        }
        fila.removeCallbacksAndMessages(null);
        fila.postDelayed(() -> salvarAgora(c), 1500);
    }

    /** Grava o backup no arquivo. Retorna true se deu certo. */
    public static boolean salvarAgora(Context c) {
        Uri uri = arquivo(c);
        if (uri == null) return false;
        try (OutputStream out = c.getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("sem acesso");
            out.write(gerarJson(c).getBytes(StandardCharsets.UTF_8));
            out.flush();
            prefs(c).edit().putLong("ultimo", System.currentTimeMillis()).putBoolean("erro", false).apply();
            return true;
        } catch (Exception e) {
            prefs(c).edit().putBoolean("erro", true).apply();
            return false;
        }
    }

    public static String gerarJson(Context c) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("app", "NaoEsquece");
        o.put("versaoBackup", 1);
        o.put("criadoEm", System.currentTimeMillis());
        JSONArray lista = new JSONArray();
        for (Reminder r : Store.todos(c)) lista.put(r.toJson());
        o.put("lembretes", lista);
        JSONObject ap = new JSONObject();
        ap.put("cor", Ui.cor(c));
        ap.put("fundo", Ui.fundo(c));
        ap.put("escurecer", Ui.escurecer(c));
        ap.put("gradual", Ui.volumeGradual(c));
        o.put("aparencia", ap);
        return o.toString(2);
    }

    public static String ler(Context c, Uri uri) throws Exception {
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String linha;
            while ((linha = br.readLine()) != null) sb.append(linha).append('\n');
            return sb.toString();
        }
    }

    /** Lê os lembretes de um backup (sem aplicar). Lança exceção se o arquivo não for válido. */
    public static List<Reminder> lembretesDo(String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        if (!"NaoEsquece".equals(o.optString("app"))) throw new JSONException("não é um backup do Não Esquece");
        JSONArray a = o.getJSONArray("lembretes");
        List<Reminder> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) out.add(Reminder.fromJson(a.getJSONObject(i)));
        return out;
    }

    /** Substitui os lembretes atuais pelos do backup e reagenda os alarmes. */
    public static int restaurar(Context c, String json) throws JSONException {
        List<Reminder> novos = lembretesDo(json);
        JSONObject o = new JSONObject(json);

        for (Reminder antigo : Store.todos(c)) Scheduler.cancelar(c, antigo.id);

        long agora = System.currentTimeMillis();
        for (Reminder r : novos) {
            r.sonecas = 0;
            if (!r.ativo()) continue;
            if (r.repete != Reminder.REPETE_NAO) {
                r.status = Reminder.AGENDADO;
                r.proximo = r.calcularProximo(agora);
            } else {
                long quando = r.calcularProximo(agora);
                if (quando <= agora) {
                    r.status = Reminder.FEITO;
                } else {
                    r.status = Reminder.AGENDADO;
                    r.proximo = quando;
                }
            }
        }
        Store.substituirTudo(c, novos);
        for (Reminder r : novos) Scheduler.agendar(c, r);

        JSONObject ap = o.optJSONObject("aparencia");
        if (ap != null) {
            Ui.prefs(c).edit()
                    .putInt("cor", ap.optInt("cor", Ui.cor(c)))
                    .putInt("fundo", ap.optInt("fundo", Ui.fundo(c)))
                    .putInt("escurecer", ap.optInt("escurecer", Ui.escurecer(c)))
                    .putBoolean("gradual", ap.optBoolean("gradual", true))
                    .apply();
        }
        return novos.size();
    }
}
