package br.com.naoesquece;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/** Criar ou editar um lembrete (alarme + bloco de notas). */
public class EditActivity extends Activity {
    private Reminder r;
    private EditText titulo, nota;
    private TextView hora, data, resumo;

    // ordem na tela: seg, ter, qua, qui, sex, sáb, dom
    private static final int[] DIAS = {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
            Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};
    private static final String[] LETRAS = {"S", "T", "Q", "Q", "S", "S", "D"};
    private final TextView[] chipsDias = new TextView[7];

    private final TextView[] chipsAviso = new TextView[Reminder.AVISO_OPCOES.length];

    private static final int[] SONECAS = {1, 3, 5, 10, 15};
    private final TextView[] chipsSoneca = new TextView[SONECAS.length];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int id = getIntent().getIntExtra("id", -1);
        r = id > 0 ? Store.pegar(this, id) : null;
        if (r == null) {
            r = new Reminder();
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MINUTE, 30);
            r.hora = c.get(Calendar.HOUR_OF_DAY);
            r.minuto = c.get(Calendar.MINUTE);
            r.data = c.getTimeInMillis();
        }
        if (r.data == 0) r.data = System.currentTimeMillis();
        montar();
    }

    private void montar() {
        int cor = Ui.cor(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        tela.setPadding(p, p, p, p);

        ScrollView scroll = new ScrollView(this);
        LinearLayout corpo = new LinearLayout(this);
        corpo.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(corpo);
        tela.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        // Hora (grande) + resumo
        LinearLayout cHora = Ui.cartao(this);
        cHora.setGravity(Gravity.CENTER_HORIZONTAL);
        hora = Ui.texto(this, "", 56, cor, false);
        hora.setTypeface(Ui.FINO);
        hora.setGravity(Gravity.CENTER);
        hora.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> {
            r.hora = h;
            r.minuto = m;
            atualizar();
        }, r.hora, r.minuto, true).show());
        cHora.addView(hora);
        resumo = Ui.texto(this, "", 13, 0xFF757575, false);
        resumo.setGravity(Gravity.CENTER);
        cHora.addView(resumo);
        corpo.addView(cHora);

        // O que é + bloco de notas
        LinearLayout c1 = Ui.cartao(this);
        c1.addView(Ui.rotulo(this, "O que é"));
        titulo = campo("Ex.: Pagar o boleto da luz", r.titulo, 17, false);
        c1.addView(titulo);
        c1.addView(Ui.rotulo(this, "Anotação · por que esse alarme existe"), Ui.linha(this, 10));
        nota = campo("O que fazer, onde está, com quem falar…", r.nota, 15, true);
        c1.addView(nota);
        corpo.addView(c1);

        // Repetir
        LinearLayout c2 = Ui.cartao(this);
        c2.addView(Ui.rotulo(this, "Repetir nos dias"));
        for (int i = 0; i < 7; i++) {
            final int dia = DIAS[i];
            TextView t = Ui.chip(this, LETRAS[i]);
            t.setOnClickListener(v -> {
                r.dias ^= (1 << dia);
                r.repete = r.dias == 0 ? Reminder.REPETE_NAO : Reminder.REPETE_DIAS;
                atualizar();
            });
            chipsDias[i] = t;
        }
        c2.addView(Ui.linhaDeChips(this, chipsDias), Ui.linha(this, 8));

        LinearLayout atalhos = new LinearLayout(this);
        atalhos.addView(atalho("Todo dia", Reminder.TODOS_DIAS));
        atalhos.addView(atalho("Seg a sex", Reminder.SEG_A_SEX));
        atalhos.addView(atalho("Nenhum", 0));
        c2.addView(atalhos, Ui.linha(this, 4));

        data = Ui.texto(this, "", 14, cor, false);
        data.setTypeface(Ui.MEDIO);
        data.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
        data.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(r.data);
            new DatePickerDialog(this, (dp, y, mo, d) -> {
                Calendar n = Calendar.getInstance();
                n.set(y, mo, d, 12, 0, 0);
                r.data = n.getTimeInMillis();
                atualizar();
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        c2.addView(data);
        corpo.addView(c2);

        // Aviso antes (pode marcar vários)
        LinearLayout c3 = Ui.cartao(this);
        c3.addView(Ui.rotulo(this, "Avisar antes · pode marcar vários"));
        for (int i = 0; i < Reminder.AVISO_OPCOES.length; i++) {
            final int bit = 1 << i;
            TextView t = Ui.chip(this, Reminder.avisoNome(Reminder.AVISO_OPCOES[i]));
            t.setOnClickListener(v -> {
                r.avisos ^= bit;
                atualizar();
            });
            chipsAviso[i] = t;
        }
        c3.addView(Ui.linhaDeChips(this, new TextView[]{chipsAviso[0], chipsAviso[1], chipsAviso[2], chipsAviso[3]}),
                Ui.linha(this, 8));
        c3.addView(Ui.linhaDeChips(this, new TextView[]{chipsAviso[4], chipsAviso[5], chipsAviso[6]}),
                Ui.linha(this, 6));

        // Soneca
        c3.addView(Ui.rotulo(this, "Soneca"), Ui.linha(this, 12));
        for (int i = 0; i < SONECAS.length; i++) {
            final int min = SONECAS[i];
            TextView t = Ui.chip(this, min + " min");
            t.setOnClickListener(v -> {
                r.sonecaMin = min;
                atualizar();
            });
            chipsSoneca[i] = t;
        }
        c3.addView(Ui.linhaDeChips(this, chipsSoneca), Ui.linha(this, 8));
        corpo.addView(c3);

        if (r.id > 0) {
            TextView apagar = Ui.texto(this, "Apagar lembrete", 14, 0xFFD32F2F, false);
            apagar.setTypeface(Ui.MEDIO);
            apagar.setGravity(Gravity.CENTER);
            apagar.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            apagar.setBackground(Ui.redondo(0xF0FFFFFF, Ui.dp(this, 16)));
            apagar.setOnClickListener(v -> confirmarApagar());
            corpo.addView(apagar, Ui.linha(this, 0));
        }

        LinearLayout rodape = new LinearLayout(this);
        Button cancelar = Ui.botao(this, "Cancelar", 0xE6FFFFFF);
        cancelar.setOnClickListener(v -> finish());
        Button salvar = Ui.botao(this, "Salvar", cor);
        salvar.setOnClickListener(v -> salvar());
        rodape.addView(cancelar, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(0, Ui.WRAP, 2);
        lpS.setMargins(Ui.dp(this, 8), 0, 0, 0);
        rodape.addView(salvar, lpS);
        tela.addView(rodape, Ui.linha(this, 8));

        Ui.moldura(this, tela);
        atualizar();
    }

    private EditText campo(String dica, String valor, float sp, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(dica);
        e.setText(valor);
        e.setTextSize(sp);
        e.setBackground(null);
        e.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        int tipo = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
        if (multi) {
            tipo |= InputType.TYPE_TEXT_FLAG_MULTI_LINE;
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setInputType(tipo);
        return e;
    }

    private TextView atalho(String texto, int mask) {
        TextView t = Ui.texto(this, texto, 13, 0xFF757575, false);
        t.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        t.setOnClickListener(v -> {
            r.dias = mask;
            r.repete = mask == 0 ? Reminder.REPETE_NAO : Reminder.REPETE_DIAS;
            atualizar();
        });
        return t;
    }

    private void atualizar() {
        hora.setText(r.horaTexto());
        for (int i = 0; i < 7; i++) {
            Ui.marcarChip(this, chipsDias[i], r.repete == Reminder.REPETE_DIAS && (r.dias & (1 << DIAS[i])) != 0);
        }
        for (int i = 0; i < chipsAviso.length; i++) Ui.marcarChip(this, chipsAviso[i], (r.avisos & (1 << i)) != 0);
        for (int i = 0; i < SONECAS.length; i++) Ui.marcarChip(this, chipsSoneca[i], r.sonecaMin == SONECAS[i]);

        boolean umaVez = r.repete == Reminder.REPETE_NAO;
        data.setVisibility(umaVez ? View.VISIBLE : View.GONE);
        data.setText("📅  " + new SimpleDateFormat("EEEE, dd/MM/yyyy", Reminder.BR).format(new Date(r.data))
                + "  (toque para mudar)");
        String res = umaVez ? "Uma vez" : r.repeteTexto();
        if (umaVez) {
            int faltam = Reminder.diasAte(r.data);
            if (faltam >= 2) res += " · faltam " + faltam + " dias";
        }
        resumo.setText(res + " · toque na hora para mudar");
    }

    private void salvar() {
        r.titulo = titulo.getText().toString().trim();
        r.nota = nota.getText().toString();
        if (r.titulo.isEmpty()) r.titulo = "Lembrete";

        if (Reminder.TOCANDO.equals(r.status)) {
            // Está tocando: só guarda o texto, o alarme continua até marcar como feito
            Store.salvar(this, r);
            finish();
            return;
        }

        long agora = System.currentTimeMillis();
        if (r.repete == Reminder.REPETE_NAO) {
            long quando = r.calcularProximo(agora);
            if (quando <= agora) {
                Calendar hoje = Calendar.getInstance();
                Calendar escolhido = Calendar.getInstance();
                escolhido.setTimeInMillis(r.data);
                boolean ehHoje = hoje.get(Calendar.YEAR) == escolhido.get(Calendar.YEAR)
                        && hoje.get(Calendar.DAY_OF_YEAR) == escolhido.get(Calendar.DAY_OF_YEAR);
                if (ehHoje) {
                    escolhido.add(Calendar.DAY_OF_YEAR, 1);
                    r.data = escolhido.getTimeInMillis();
                } else {
                    Toast.makeText(this, "Esse dia e horário já passaram. Escolha outro.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
        r.status = Reminder.AGENDADO;
        r.sonecas = 0;
        r.proximo = r.calcularProximo(agora);
        Store.salvar(this, r);
        Scheduler.agendar(this, r);
        Toast.makeText(this, "Vai tocar " + Reminder.diaTexto(r.proximo) + " às " + Reminder.so_hora(r.proximo),
                Toast.LENGTH_LONG).show();
        finish();
    }

    private void confirmarApagar() {
        new AlertDialog.Builder(this)
                .setTitle("Apagar lembrete?")
                .setMessage("\"" + r.tituloOuPadrao() + "\" será apagado.")
                .setPositiveButton("Apagar", (d, w) -> {
                    boolean tocava = Reminder.TOCANDO.equals(r.status);
                    Scheduler.cancelar(this, r.id);
                    Store.apagar(this, r.id);
                    if (tocava) {
                        startForegroundService(new Intent(this, AlarmService.class)
                                .setAction(AlarmService.FEITO).putExtra("id", r.id));
                    }
                    finish();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
