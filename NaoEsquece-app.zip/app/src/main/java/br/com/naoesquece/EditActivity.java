package br.com.naoesquece;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/** Criar ou editar um lembrete (alarme + bloco de notas). */
public class EditActivity extends Activity {
    private Reminder r;
    private EditText titulo, nota;
    private Button botaoHora, botaoData;
    private final Button[] botoesRepete = new Button[3];
    private final int[] opcoesSoneca = {1, 3, 5, 10, 15};
    private final Button[] botoesSoneca = new Button[5];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int id = getIntent().getIntExtra("id", -1);
        r = id > 0 ? Store.pegar(this, id) : null;
        if (r == null) {
            r = new Reminder();
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MINUTE, 30);
            r.hora = c.get(Calendar.HOUR_OF_DAY);
            r.minuto = c.get(Calendar.MINUTE);
            r.data = c.getTimeInMillis();
        }
        montar();
    }

    private void montar() {
        int cor = Ui.cor(this);
        int txt = Ui.textoFundo(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        tela.setPadding(p, p, p, p);

        tela.addView(Ui.texto(this, r.id > 0 ? "Editar lembrete" : "Novo lembrete", 26, txt, true));

        ScrollView scroll = new ScrollView(this);
        LinearLayout corpo = new LinearLayout(this);
        corpo.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(corpo);
        tela.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        // O que é
        LinearLayout c1 = Ui.cartao(this);
        c1.addView(Ui.texto(this, "O que é?", 15, 0xFF555555, true));
        titulo = new EditText(this);
        titulo.setHint("Ex.: Pagar o boleto da luz");
        titulo.setText(r.titulo);
        titulo.setTextSize(19);
        titulo.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        c1.addView(titulo);
        c1.addView(Ui.texto(this, "📝 Bloco de notas — por que esse alarme existe", 15, 0xFF555555, true),
                Ui.linha(this, 12));
        nota = new EditText(this);
        nota.setHint("Escreva aqui tudo que você vai precisar lembrar quando o alarme tocar: o que fazer, onde está, com quem falar…");
        nota.setText(r.nota);
        nota.setMinLines(5);
        nota.setGravity(Gravity.TOP | Gravity.START);
        nota.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        c1.addView(nota);
        corpo.addView(c1);

        // Quando
        LinearLayout c2 = Ui.cartao(this);
        c2.addView(Ui.texto(this, "Quando tocar?", 15, 0xFF555555, true));
        botaoHora = Ui.botao(this, "", cor);
        botaoHora.setTextSize(30);
        botaoHora.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> {
            r.hora = h;
            r.minuto = m;
            atualizar();
        }, r.hora, r.minuto, true).show());
        c2.addView(botaoHora, Ui.linha(this, 8));

        LinearLayout repete = new LinearLayout(this);
        String[] nomes = {"Uma vez", "Todo dia", "Seg a sex"};
        for (int i = 0; i < 3; i++) {
            final int qual = i;
            Button bt = Ui.botao(this, nomes[i], cor);
            bt.setTextSize(15);
            bt.setOnClickListener(v -> {
                r.repete = qual;
                atualizar();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            lp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), 0, 0, 0);
            repete.addView(bt, lp);
            botoesRepete[i] = bt;
        }
        c2.addView(repete, Ui.linha(this, 10));

        botaoData = Ui.botao(this, "", 0xFF607D8B);
        botaoData.setTextSize(16);
        botaoData.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(r.data);
            new DatePickerDialog(this, (dp, y, mo, d) -> {
                Calendar n = Calendar.getInstance();
                n.set(y, mo, d, 12, 0, 0);
                r.data = n.getTimeInMillis();
                atualizar();
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        c2.addView(botaoData, Ui.linha(this, 10));
        corpo.addView(c2);

        // Soneca
        LinearLayout c3 = Ui.cartao(this);
        c3.addView(Ui.texto(this, "😴 Soneca de quantos minutos?", 15, 0xFF555555, true));
        LinearLayout sonecas = new LinearLayout(this);
        for (int i = 0; i < opcoesSoneca.length; i++) {
            final int min = opcoesSoneca[i];
            Button bt = Ui.botao(this, String.valueOf(min), cor);
            bt.setTextSize(15);
            bt.setOnClickListener(v -> {
                r.sonecaMin = min;
                atualizar();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            lp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), 0, 0, 0);
            sonecas.addView(bt, lp);
            botoesSoneca[i] = bt;
        }
        c3.addView(sonecas, Ui.linha(this, 8));
        corpo.addView(c3);

        if (r.id > 0) {
            Button apagar = Ui.botao(this, "🗑️ Apagar lembrete", 0xFFB71C1C);
            apagar.setOnClickListener(v -> confirmarApagar());
            corpo.addView(apagar, Ui.linha(this, 4));
        }

        Button salvar = Ui.botao(this, "Salvar", 0xFF2E7D32);
        salvar.setTextSize(19);
        salvar.setOnClickListener(v -> salvar());
        tela.addView(salvar, Ui.linha(this, 8));

        Ui.moldura(this, tela);
        atualizar();
    }

    private void atualizar() {
        int cor = Ui.cor(this);
        botaoHora.setText(r.horaTexto());
        for (int i = 0; i < 3; i++) marcar(botoesRepete[i], r.repete == i, cor);
        for (int i = 0; i < opcoesSoneca.length; i++) marcar(botoesSoneca[i], r.sonecaMin == opcoesSoneca[i], cor);
        botaoData.setVisibility(r.repete == Reminder.REPETE_NAO ? android.view.View.VISIBLE : android.view.View.GONE);
        botaoData.setText("📅 Dia: " + new SimpleDateFormat("EEEE, dd/MM/yyyy", Reminder.BR).format(new Date(r.data)));
    }

    private void marcar(Button b, boolean ativo, int cor) {
        b.setBackground(Ui.redondo(ativo ? cor : 0xFFE0E0E0, Ui.dp(this, 28)));
        b.setTextColor(ativo ? Color.WHITE : 0xFF424242);
    }

    private void salvar() {
        r.titulo = titulo.getText().toString().trim();
        r.nota = nota.getText().toString();
        if (r.titulo.isEmpty()) r.titulo = "Lembrete";

        if (Reminder.TOCANDO.equals(r.status)) {
            // Está tocando: só guarda o texto, o alarme continua até marcar como feito
            Store.salvar(this, r);
            finish();
            return;
        }

        long agora = System.currentTimeMillis();
        if (r.repete == Reminder.REPETE_NAO) {
            long quando = r.calcularProximo(agora);
            if (quando <= agora) {
                Calendar hoje = Calendar.getInstance();
                Calendar escolhido = Calendar.getInstance();
                escolhido.setTimeInMillis(r.data);
                boolean ehHoje = hoje.get(Calendar.YEAR) == escolhido.get(Calendar.YEAR)
                        && hoje.get(Calendar.DAY_OF_YEAR) == escolhido.get(Calendar.DAY_OF_YEAR);
                if (ehHoje) {
                    escolhido.add(Calendar.DAY_OF_YEAR, 1);
                    r.data = escolhido.getTimeInMillis();
                } else {
                    Toast.makeText(this, "Esse dia e horário já passaram. Escolha outro.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
        r.status = Reminder.AGENDADO;
        r.sonecas = 0;
        r.proximo = r.calcularProximo(agora);
        Store.salvar(this, r);
        Scheduler.agendar(this, r);
        Toast.makeText(this, "Vai tocar " + Reminder.quando(r.proximo), Toast.LENGTH_LONG).show();
        finish();
    }

    private void confirmarApagar() {
        new AlertDialog.Builder(this)
                .setTitle("Apagar lembrete?")
                .setMessage("\"" + r.tituloOuPadrao() + "\" será apagado.")
                .setPositiveButton("Apagar", (d, w) -> {
                    boolean tocava = Reminder.TOCANDO.equals(r.status);
                    Scheduler.cancelar(this, r.id);
                    Store.apagar(this, r.id);
                    if (tocava) {
                        startForegroundService(new Intent(this, AlarmService.class)
                                .setAction(AlarmService.FEITO).putExtra("id", r.id));
                    }
                    finish();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
