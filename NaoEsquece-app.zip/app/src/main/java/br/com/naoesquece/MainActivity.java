package br.com.naoesquece;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout lista;
    private LinearLayout avisos;

    private final BroadcastReceiver mudou = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            desenharLista();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        montarTela();
        IntentFilter f = new IntentFilter(AlarmService.MUDOU);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(mudou, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(mudou, f);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(mudou);
        } catch (Exception ignored) {
        }
    }

    private void montarTela() {
        int cor = Ui.cor(this);
        int txt = Ui.textoFundo(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        tela.setPadding(p, p, p, p);

        // Cabeçalho
        LinearLayout topo = new LinearLayout(this);
        topo.setGravity(Gravity.CENTER_VERTICAL);
        TextView titulo = Ui.texto(this, "Não Esquece", 28, txt, true);
        topo.addView(titulo, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        Button aparencia = Ui.botao(this, "🎨", 0x33FFFFFF);
        aparencia.setTextSize(22);
        aparencia.setOnClickListener(v -> startActivity(new Intent(this, AparenciaActivity.class)));
        topo.addView(aparencia, new LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56)));
        tela.addView(topo);

        avisos = new LinearLayout(this);
        avisos.setOrientation(LinearLayout.VERTICAL);
        tela.addView(avisos, Ui.linha(this, 12));

        ScrollView scroll = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(lista);
        tela.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        Button novo = Ui.botao(this, "+  Novo lembrete", cor);
        novo.setTextSize(19);
        novo.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class)));
        tela.addView(novo, Ui.linha(this, 8));

        Ui.moldura(this, tela);
        desenharAvisos();
        desenharLista();
    }

    // ---------- avisos de permissão (para o alarme não falhar) ----------

    private void desenharAvisos() {
        avisos.removeAllViews();
        NotificationManager nm = getSystemService(NotificationManager.class);
        AlarmManager am = getSystemService(AlarmManager.class);
        PowerManager pm = getSystemService(PowerManager.class);
        String pkg = getPackageName();

        if (!nm.areNotificationsEnabled()) {
            aviso("🔕 As notificações estão desligadas. Sem elas o alarme não aparece.", "Ligar notificações", () -> {
                if (Build.VERSION.SDK_INT >= 33 && shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, pkg));
                }
            });
        }
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            aviso("⏱️ Permita \"Alarmes e lembretes\" para tocar na hora certa.", "Permitir", () ->
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + pkg))));
        }
        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
            aviso("📱 Permita abrir em tela cheia para o alarme aparecer com o celular bloqueado.", "Permitir", () ->
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + pkg))));
        }
        if (!pm.isIgnoringBatteryOptimizations(pkg)) {
            aviso("🔋 Libere o app da economia de bateria para o Android não desligar o alarme.", "Liberar", () -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + pkg)));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
        }
    }

    private void aviso(String texto, String botao, Runnable acao) {
        LinearLayout c = Ui.cartao(this);
        c.setBackground(Ui.redondo(0xFFFFF8E1, Ui.dp(this, 18)));
        c.addView(Ui.texto(this, texto, 15, 0xFF5D4037, false));
        Button b = Ui.botao(this, botao, 0xFFFF8F00);
        b.setOnClickListener(v -> acao.run());
        c.addView(b, Ui.linha(this, 8));
        avisos.addView(c);
    }

    // ---------- lista de lembretes ----------

    private int ordem(Reminder r) {
        switch (r.status) {
            case Reminder.TOCANDO: return 0;
            case Reminder.SONECA: return 1;
            case Reminder.AGENDADO: return 2;
            default: return 3;
        }
    }

    private void desenharLista() {
        if (lista == null) return;
        lista.removeAllViews();
        List<Reminder> todos = new ArrayList<>(Store.todos(this));
        Collections.sort(todos, (a, b) -> {
            int o = Integer.compare(ordem(a), ordem(b));
            return o != 0 ? o : Long.compare(a.proximo, b.proximo);
        });

        if (todos.isEmpty()) {
            LinearLayout c = Ui.cartao(this);
            c.addView(Ui.texto(this, "Nenhum lembrete ainda", 18, 0xFF212121, true));
            c.addView(Ui.texto(this,
                    "Toque em \"+ Novo lembrete\", escreva o que você precisa fazer e escolha a hora.\n\n"
                            + "Quando tocar, só existe SONECA. O alarme só para de vez quando você "
                            + "abre o app e marca como FEITO.", 15, 0xFF555555, false), Ui.linha(this, 6));
            lista.addView(c);
            return;
        }

        int cor = Ui.cor(this);
        for (Reminder r : todos) {
            LinearLayout c = Ui.cartao(this);
            boolean feito = !r.ativo();
            if (feito) c.setAlpha(0.6f);

            c.addView(Ui.texto(this, r.tituloOuPadrao(), 19, 0xFF212121, true));

            String status;
            int corStatus = 0xFF555555;
            switch (r.status) {
                case Reminder.TOCANDO:
                    status = "🔔 TOCANDO AGORA — toque para ver";
                    corStatus = 0xFFD32F2F;
                    break;
                case Reminder.SONECA:
                    status = "😴 Soneca — volta a tocar às " + Reminder.so_hora(r.proximo);
                    corStatus = 0xFFE65100;
                    break;
                case Reminder.AGENDADO:
                    status = "⏰ " + Reminder.quando(r.proximo) + "  ·  " + r.repeteTexto();
                    break;
                default:
                    status = "✓ Feito";
            }
            c.addView(Ui.texto(this, status, 15, corStatus, !feito && !Reminder.AGENDADO.equals(r.status)),
                    Ui.linha(this, 4));

            if (r.nota != null && !r.nota.trim().isEmpty()) {
                TextView nota = Ui.texto(this, "📝 " + r.nota.trim(), 14, 0xFF666666, false);
                nota.setMaxLines(2);
                nota.setEllipsize(android.text.TextUtils.TruncateAt.END);
                c.addView(nota, Ui.linha(this, 4));
            }

            if (Reminder.TOCANDO.equals(r.status) || Reminder.SONECA.equals(r.status)) {
                Button b = Ui.botao(this, "✅ Marcar como feito", 0xFF2E7D32);
                b.setOnClickListener(v -> {
                    Intent i = new Intent(this, AlarmActivity.class).putExtra("id", r.id);
                    startActivity(i);
                });
                c.addView(b, Ui.linha(this, 10));
            }

            c.setOnClickListener(v -> {
                if (Reminder.TOCANDO.equals(r.status) || Reminder.SONECA.equals(r.status)) {
                    startActivity(new Intent(this, AlarmActivity.class).putExtra("id", r.id));
                } else {
                    startActivity(new Intent(this, EditActivity.class).putExtra("id", r.id));
                }
            });
            lista.addView(c);
        }
    }
}
