package br.com.naoesquece;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout lista;
    private LinearLayout avisos;

    private final BroadcastReceiver mudou = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            desenharLista();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        montarTela();
        IntentFilter f = new IntentFilter(AlarmService.MUDOU);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(mudou, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(mudou, f);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(mudou);
        } catch (Exception ignored) {
        }
    }

    private void montarTela() {
        int cor = Ui.cor(this);
        int txt = Ui.textoFundo(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        tela.setPadding(p, p, p, p);

        // Cabeçalho
        LinearLayout topo = new LinearLayout(this);
        topo.setGravity(Gravity.CENTER_VERTICAL);
        TextView titulo = Ui.texto(this, "Não Esquece", 22, txt, false);
        titulo.setTypeface(Ui.MEDIO);
        topo.addView(titulo, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        TextView aparencia = Ui.chip(this, "🎨");
        aparencia.setTextSize(18);
        aparencia.setBackground(Ui.redondo(0x22FFFFFF, Ui.dp(this, 20)));
        aparencia.setOnClickListener(v -> startActivity(new Intent(this, AparenciaActivity.class)));
        topo.addView(aparencia, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)));
        tela.addView(topo);

        avisos = new LinearLayout(this);
        avisos.setOrientation(LinearLayout.VERTICAL);
        tela.addView(avisos, Ui.linha(this, 12));

        ScrollView scroll = new ScrollView(this);
        lista = new LinearLayout(this);
        lista.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(lista);
        tela.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        Button novo = Ui.botao(this, "+  Novo lembrete", cor);
        novo.setTextSize(16);
        novo.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class)));
        tela.addView(novo, Ui.linha(this, 8));

        Ui.moldura(this, tela);
        desenharAvisos();
        desenharLista();
    }

    // ---------- avisos de permissão (para o alarme não falhar) ----------

    private void desenharAvisos() {
        avisos.removeAllViews();
        NotificationManager nm = getSystemService(NotificationManager.class);
        AlarmManager am = getSystemService(AlarmManager.class);
        PowerManager pm = getSystemService(PowerManager.class);
        String pkg = getPackageName();

        if (!nm.areNotificationsEnabled()) {
            aviso("🔕 As notificações estão desligadas. Sem elas o alarme não aparece.", "Ligar notificações", () -> {
                if (Build.VERSION.SDK_INT >= 33 && shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, pkg));
                }
            });
        }
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            aviso("⏱️ Permita \"Alarmes e lembretes\" para tocar na hora certa.", "Permitir", () ->
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + pkg))));
        }
        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
            aviso("📱 Permita abrir em tela cheia para o alarme aparecer com o celular bloqueado.", "Permitir", () ->
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + pkg))));
        }
        if (!pm.isIgnoringBatteryOptimizations(pkg)) {
            aviso("🔋 Libere o app da economia de bateria para o Android não desligar o alarme.", "Liberar", () -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + pkg)));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
        }
    }

    private void aviso(String texto, String botao, Runnable acao) {
        LinearLayout c = Ui.cartao(this);
        c.setBackground(Ui.redondo(0xFFFFF8E1, Ui.dp(this, 18)));
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(Ui.texto(this, texto, 13, 0xFF5D4037, false), new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        Button b = Ui.botao(this, botao, 0xFFFF8F00);
        b.setTextSize(13);
        b.setOnClickListener(v -> acao.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        lp.setMargins(Ui.dp(this, 8), 0, 0, 0);
        c.addView(b, lp);
        avisos.addView(c);
    }

    // ---------- lista de lembretes ----------

    private int ordem(Reminder r) {
        switch (r.status) {
            case Reminder.TOCANDO: return 0;
            case Reminder.SONECA: return 1;
            case Reminder.AGENDADO: return 2;
            default: return 3;
        }
    }

    private void desenharLista() {
        if (lista == null) return;
        lista.removeAllViews();
        List<Reminder> todos = new ArrayList<>(Store.todos(this));
        Collections.sort(todos, (a, b) -> {
            int o = Integer.compare(ordem(a), ordem(b));
            return o != 0 ? o : Long.compare(a.proximo, b.proximo);
        });

        if (todos.isEmpty()) {
            LinearLayout c = Ui.cartao(this);
            c.addView(Ui.texto(this, "Nenhum lembrete ainda", 16, 0xFF212121, true));
            c.addView(Ui.texto(this,
                    "Toque em \"+ Novo lembrete\", escreva o que você precisa fazer e escolha a hora.\n\n"
                            + "Quando tocar, só existe SONECA. O alarme só para de vez quando você "
                            + "abre o app e marca como FEITO.", 15, 0xFF555555, false), Ui.linha(this, 6));
            lista.addView(c);
            return;
        }

        int cor = Ui.cor(this);
        for (Reminder r : todos) {
            LinearLayout c = Ui.cartao(this);
            boolean feito = !r.ativo();
            boolean tocando = Reminder.TOCANDO.equals(r.status);
            boolean soneca = Reminder.SONECA.equals(r.status);
            if (feito) c.setAlpha(0.55f);

            LinearLayout linha = new LinearLayout(this);
            linha.setGravity(Gravity.CENTER_VERTICAL);
            String horaGrande = tocando ? "⏰" : Reminder.so_hora(r.ativo() ? r.proximo : r.calcularProximo(System.currentTimeMillis()));
            if (feito) horaGrande = r.horaTexto();
            TextView hora = Ui.texto(this, horaGrande, 26, tocando ? 0xFFD32F2F : soneca ? 0xFFE65100 : cor, false);
            hora.setTypeface(Ui.FINO);
            linha.addView(hora, new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.WRAP));

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView tit = Ui.texto(this, r.tituloOuPadrao(), 16, 0xFF212121, false);
            tit.setTypeface(Ui.MEDIO);
            tit.setMaxLines(1);
            tit.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(tit);

            String sub;
            int corSub = 0xFF757575;
            if (tocando) { sub = "Tocando agora"; corSub = 0xFFD32F2F; }
            else if (soneca) { sub = "Soneca · volta às " + Reminder.so_hora(r.proximo); corSub = 0xFFE65100; }
            else if (feito) sub = "Feito";
            else {
                sub = Reminder.diaTexto(r.proximo) + " · " + r.repeteTexto();
                if (r.avisoMin > 0) sub += " · aviso " + r.avisoMin + " min";
            }
            col.addView(Ui.texto(this, sub, 13, corSub, false));

            if (r.nota != null && !r.nota.trim().isEmpty()) {
                TextView nota = Ui.texto(this, r.nota.trim(), 13, 0xFF9E9E9E, false);
                nota.setMaxLines(1);
                nota.setEllipsize(android.text.TextUtils.TruncateAt.END);
                col.addView(nota);
            }
            linha.addView(col, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
            c.addView(linha);

            if (tocando || soneca) {
                Button b = Ui.botao(this, "Marcar como feito", 0xFF2E7D32);
                b.setTextSize(14);
                b.setOnClickListener(v -> startActivity(new Intent(this, AlarmActivity.class).putExtra("id", r.id)));
                c.addView(b, Ui.linha(this, 8));
            }

            c.setOnClickListener(v -> {
                if (Reminder.TOCANDO.equals(r.status) || Reminder.SONECA.equals(r.status)) {
                    startActivity(new Intent(this, AlarmActivity.class).putExtra("id", r.id));
                } else {
                    startActivity(new Intent(this, EditActivity.class).putExtra("id", r.id));
                }
            });
            lista.addView(c);
        }
    }
}
