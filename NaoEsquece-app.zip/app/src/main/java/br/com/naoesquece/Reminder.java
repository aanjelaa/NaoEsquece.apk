package br.com.naoesquece;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Um lembrete: alarme + anotação (o "porquê" do alarme). */
public class Reminder {
    public static final int REPETE_NAO = 0, REPETE_TODO_DIA = 1, REPETE_DIAS_UTEIS = 2;
    public static final String AGENDADO = "agendado", TOCANDO = "tocando", SONECA = "soneca", FEITO = "feito";

    public static final Locale BR = new Locale("pt", "BR");

    public int id;
    public String titulo = "";
    public String nota = "";
    public int hora = 8, minuto = 0;
    public long data;               // dia escolhido (para "uma vez")
    public int repete = REPETE_NAO;
    public int sonecaMin = 5;
    public String status = AGENDADO;
    public long proximo;            // quando vai tocar de novo
    public int sonecas;             // quantas sonecas seguidas

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("titulo", titulo);
        o.put("nota", nota);
        o.put("hora", hora);
        o.put("minuto", minuto);
        o.put("data", data);
        o.put("repete", repete);
        o.put("sonecaMin", sonecaMin);
        o.put("status", status);
        o.put("proximo", proximo);
        o.put("sonecas", sonecas);
        return o;
    }

    public static Reminder fromJson(JSONObject o) {
        Reminder r = new Reminder();
        r.id = o.optInt("id");
        r.titulo = o.optString("titulo", "");
        r.nota = o.optString("nota", "");
        r.hora = o.optInt("hora", 8);
        r.minuto = o.optInt("minuto", 0);
        r.data = o.optLong("data", System.currentTimeMillis());
        r.repete = o.optInt("repete", REPETE_NAO);
        r.sonecaMin = o.optInt("sonecaMin", 5);
        r.status = o.optString("status", AGENDADO);
        r.proximo = o.optLong("proximo", 0);
        r.sonecas = o.optInt("sonecas", 0);
        return r;
    }

    public boolean ativo() {
        return !FEITO.equals(status);
    }

    /** Próximo horário "normal" (sem soneca) depois de 'depois'. */
    public long calcularProximo(long depois) {
        Calendar c = Calendar.getInstance();
        if (repete == REPETE_NAO) {
            c.setTimeInMillis(data);
            c.set(Calendar.HOUR_OF_DAY, hora);
            c.set(Calendar.MINUTE, minuto);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            return c.getTimeInMillis();
        }
        c.setTimeInMillis(depois);
        c.set(Calendar.HOUR_OF_DAY, hora);
        c.set(Calendar.MINUTE, minuto);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= depois) c.add(Calendar.DAY_OF_YEAR, 1);
        if (repete == REPETE_DIAS_UTEIS) {
            while (c.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
                    || c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                c.add(Calendar.DAY_OF_YEAR, 1);
            }
        }
        return c.getTimeInMillis();
    }

    public String horaTexto() {
        return String.format(Locale.US, "%02d:%02d", hora, minuto);
    }

    public String repeteTexto() {
        switch (repete) {
            case REPETE_TODO_DIA: return "Todo dia";
            case REPETE_DIAS_UTEIS: return "Seg a sex";
            default: return "Uma vez";
        }
    }

    public String tituloOuPadrao() {
        return titulo == null || titulo.trim().isEmpty() ? "Lembrete" : titulo.trim();
    }

    public static String quando(long millis) {
        return new SimpleDateFormat("EEE, dd/MM 'às' HH:mm", BR).format(new Date(millis));
    }

    public static String so_hora(long millis) {
        return new SimpleDateFormat("HH:mm", BR).format(new Date(millis));
    }
}
