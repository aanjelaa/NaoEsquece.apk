package br.com.naoesquece;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Um lembrete: alarme + anotação (o "porquê" do alarme). */
public class Reminder {
    public static final int REPETE_NAO = 0, REPETE_DIAS = 3;
    // dias da semana: bit (1 << Calendar.DAY_OF_WEEK), domingo=1 ... sábado=7
    public static final int TODOS_DIAS = 0b11111110, SEG_A_SEX = 0b01111100, FIM_DE_SEMANA = 0b10000010;
    public static final String AGENDADO = "agendado", TOCANDO = "tocando", SONECA = "soneca", FEITO = "feito";

    public static final Locale BR = new Locale("pt", "BR");

    public int id;
    public String titulo = "";
    public String nota = "";
    public int hora = 8, minuto = 0;
    public long data;               // dia escolhido (para "uma vez")
    public int repete = REPETE_NAO;
    public int sonecaMin = 5;
    public int dias = 0;            // dias escolhidos (quando repete)
    public int avisoMin = 0;        // avisar X minutos antes (0 = não)
    public String status = AGENDADO;
    public long proximo;            // quando vai tocar de novo
    public int sonecas;             // quantas sonecas seguidas

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("titulo", titulo);
        o.put("nota", nota);
        o.put("hora", hora);
        o.put("minuto", minuto);
        o.put("data", data);
        o.put("repete", repete);
        o.put("sonecaMin", sonecaMin);
        o.put("dias", dias);
        o.put("avisoMin", avisoMin);
        o.put("status", status);
        o.put("proximo", proximo);
        o.put("sonecas", sonecas);
        return o;
    }

    public static Reminder fromJson(JSONObject o) {
        Reminder r = new Reminder();
        r.id = o.optInt("id");
        r.titulo = o.optString("titulo", "");
        r.nota = o.optString("nota", "");
        r.hora = o.optInt("hora", 8);
        r.minuto = o.optInt("minuto", 0);
        r.data = o.optLong("data", System.currentTimeMillis());
        r.repete = o.optInt("repete", REPETE_NAO);
        r.sonecaMin = o.optInt("sonecaMin", 5);
        r.dias = o.optInt("dias", 0);
        r.avisoMin = o.optInt("avisoMin", 0);
        // versão 1 guardava "todo dia" (1) e "seg a sex" (2)
        if (r.repete == 1) { r.repete = REPETE_DIAS; r.dias = TODOS_DIAS; }
        if (r.repete == 2) { r.repete = REPETE_DIAS; r.dias = SEG_A_SEX; }
        if (r.repete == REPETE_DIAS && r.dias == 0) r.repete = REPETE_NAO;
        r.status = o.optString("status", AGENDADO);
        r.proximo = o.optLong("proximo", 0);
        r.sonecas = o.optInt("sonecas", 0);
        return r;
    }

    public boolean ativo() {
        return !FEITO.equals(status);
    }

    /** Próximo horário "normal" (sem soneca) depois de 'depois'. */
    public long calcularProximo(long depois) {
        Calendar c = Calendar.getInstance();
        if (repete == REPETE_NAO) {
            c.setTimeInMillis(data);
            c.set(Calendar.HOUR_OF_DAY, hora);
            c.set(Calendar.MINUTE, minuto);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            return c.getTimeInMillis();
        }
        c.setTimeInMillis(depois);
        c.set(Calendar.HOUR_OF_DAY, hora);
        c.set(Calendar.MINUTE, minuto);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= depois) c.add(Calendar.DAY_OF_YEAR, 1);
        int mask = dias == 0 ? TODOS_DIAS : dias;
        for (int i = 0; i < 8 && (mask & (1 << c.get(Calendar.DAY_OF_WEEK))) == 0; i++) {
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
        return c.getTimeInMillis();
    }

    public String horaTexto() {
        return String.format(Locale.US, "%02d:%02d", hora, minuto);
    }

    public static final String[] DIAS_CURTOS = {"", "Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"};

    public String repeteTexto() {
        if (repete == REPETE_NAO) return "Uma vez";
        if (dias == TODOS_DIAS) return "Todo dia";
        if (dias == SEG_A_SEX) return "Seg a sex";
        if (dias == FIM_DE_SEMANA) return "Fim de semana";
        StringBuilder sb = new StringBuilder();
        int[] ordem = {2, 3, 4, 5, 6, 7, 1};
        for (int d : ordem) {
            if ((dias & (1 << d)) != 0) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(DIAS_CURTOS[d]);
            }
        }
        return sb.toString();
    }

    /** "hoje", "amanhã" ou "qua, 30/09" */
    public static String diaTexto(long millis) {
        Calendar hoje = Calendar.getInstance();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        if (c.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
                && c.get(Calendar.DAY_OF_YEAR) == hoje.get(Calendar.DAY_OF_YEAR)) return "hoje";
        hoje.add(Calendar.DAY_OF_YEAR, 1);
        if (c.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
                && c.get(Calendar.DAY_OF_YEAR) == hoje.get(Calendar.DAY_OF_YEAR)) return "amanhã";
        return new SimpleDateFormat("EEE, dd/MM", BR).format(new Date(millis));
    }

    public String tituloOuPadrao() {
        return titulo == null || titulo.trim().isEmpty() ? "Lembrete" : titulo.trim();
    }

    public static String quando(long millis) {
        return new SimpleDateFormat("EEE, dd/MM 'às' HH:mm", BR).format(new Date(millis));
    }

    public static String so_hora(long millis) {
        return new SimpleDateFormat("HH:mm", BR).format(new Date(millis));
    }
}
