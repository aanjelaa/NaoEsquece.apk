package br.com.naoesquece;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.InputStream;

/** Papel de parede, cores, som do alarme e teste. */
public class AparenciaActivity extends Activity {
    private static final int PEDIR_FOTO = 10, PEDIR_SOM = 11;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        montar();
    }

    private void montar() {
        int cor = Ui.cor(this);
        int txt = Ui.textoFundo(this);

        LinearLayout tela = new LinearLayout(this);
        tela.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        tela.setPadding(p, p, p, p);
        TextView cab = Ui.texto(this, "Aparência e ajustes", 22, txt, false);
        cab.setTypeface(Ui.MEDIO);
        tela.addView(cab);

        ScrollView scroll = new ScrollView(this);
        LinearLayout corpo = new LinearLayout(this);
        corpo.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(corpo);
        LinearLayout.LayoutParams lps = new LinearLayout.LayoutParams(Ui.MATCH, 0, 1);
        lps.setMargins(0, Ui.dp(this, 12), 0, 0);
        tela.addView(scroll, lps);

        // Papel de parede
        LinearLayout c1 = Ui.cartao(this);
        c1.addView(Ui.texto(this, "Papel de parede", 16, 0xFF212121, true));
        Button escolher = Ui.botao(this, "Escolher foto da galeria", cor);
        escolher.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i, PEDIR_FOTO);
        });
        c1.addView(escolher, Ui.linha(this, 8));
        if (Ui.temPapel(this)) {
            c1.addView(Ui.texto(this, "Escurecer a foto (para ler melhor)", 14, 0xFF555555, false), Ui.linha(this, 12));
            SeekBar escurecer = new SeekBar(this);
            escurecer.setMax(80);
            escurecer.setProgress(Ui.escurecer(this));
            escurecer.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) { }
                @Override public void onStartTrackingTouch(SeekBar s) { }
                @Override public void onStopTrackingTouch(SeekBar s) {
                    Ui.prefs(AparenciaActivity.this).edit().putInt("escurecer", s.getProgress()).apply();
                    montar();
                }
            });
            c1.addView(escurecer, Ui.linha(this, 4));
            Button remover = Ui.botao(this, "Remover papel de parede", 0xFF757575);
            remover.setOnClickListener(v -> {
                Ui.papelArquivo(this).delete();
                Ui.limparCache();
                montar();
            });
            c1.addView(remover, Ui.linha(this, 8));
        }
        corpo.addView(c1);

        // Cor principal
        LinearLayout c2 = Ui.cartao(this);
        c2.addView(Ui.texto(this, "Cor principal", 16, 0xFF212121, true));
        c2.addView(paleta(Ui.CORES, cor, "cor"), Ui.linha(this, 8));
        corpo.addView(c2);

        // Cor de fundo
        LinearLayout c3 = Ui.cartao(this);
        c3.addView(Ui.texto(this, "Cor de fundo" + (Ui.temPapel(this) ? " (usada quando não tem foto)" : ""),
                16, 0xFF212121, true));
        c3.addView(paleta(Ui.FUNDOS, Ui.fundo(this), "fundo"), Ui.linha(this, 8));
        corpo.addView(c3);

        // Som
        LinearLayout c4 = Ui.cartao(this);
        c4.addView(Ui.texto(this, "Som do alarme", 16, 0xFF212121, true));
        Button som = Ui.botao(this, "Escolher som", cor);
        som.setOnClickListener(v -> {
            Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Som do alarme");
            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
            i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
            String atual = Ui.som(this);
            if (atual != null) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(atual));
            startActivityForResult(i, PEDIR_SOM);
        });
        c4.addView(som, Ui.linha(this, 8));
        android.widget.Switch gradual = new android.widget.Switch(this);
        gradual.setText("Volume subindo aos poucos");
        gradual.setTextSize(15);
        gradual.setTextColor(0xFF212121);
        gradual.setChecked(Ui.volumeGradual(this));
        gradual.setOnCheckedChangeListener((btn, marcado) ->
                Ui.prefs(this).edit().putBoolean("gradual", marcado).apply());
        c4.addView(gradual, Ui.linha(this, 12));
        c4.addView(Ui.texto(this, "Começa baixinho e chega ao volume máximo em uns 30 segundos.",
                13, 0xFF757575, false));
        corpo.addView(c4);

        // Teste
        LinearLayout c5 = Ui.cartao(this);
        c5.addView(Ui.texto(this, "Testar", 16, 0xFF212121, true));
        c5.addView(Ui.texto(this, "Cria um alarme de teste que toca em 10 segundos. Bloqueie a tela para ver como fica.",
                14, 0xFF555555, false), Ui.linha(this, 4));
        Button testar = Ui.botao(this, "Tocar alarme de teste", 0xFF2E7D32);
        testar.setOnClickListener(v -> testar());
        c5.addView(testar, Ui.linha(this, 8));
        corpo.addView(c5);

        Button voltar = Ui.botao(this, "Pronto", cor);
        voltar.setOnClickListener(v -> finish());
        tela.addView(voltar, Ui.linha(this, 8));

        Ui.moldura(this, tela);
    }

    private View paleta(int[] cores, int selecionada, String chave) {
        GridLayout g = new GridLayout(this);
        g.setColumnCount(5);
        int tam = Ui.dp(this, 40);
        for (int c : cores) {
            View bolinha = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(c);
            if (c == selecionada) d.setStroke(Ui.dp(this, 4), 0xFF212121);
            else d.setStroke(Ui.dp(this, 1), 0xFFBDBDBD);
            bolinha.setBackground(d);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = tam;
            lp.height = tam;
            lp.setMargins(Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5));
            bolinha.setOnClickListener(v -> {
                Ui.prefs(this).edit().putInt(chave, c).apply();
                montar();
            });
            g.addView(bolinha, lp);
        }
        return g;
    }

    private void testar() {
        Reminder r = new Reminder();
        r.titulo = "Alarme de teste";
        r.nota = "Isto é um teste.\n\nRepare: só existe SONECA. Para desligar de vez, segure o botão FEITO até a barra encher.\n\n"
                + "Depois você pode apagar este lembrete na lista.";
        r.repete = Reminder.REPETE_NAO;
        r.sonecaMin = 1;
        long quando = System.currentTimeMillis() + 10_000;
        r.data = quando;
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(quando);
        r.hora = c.get(java.util.Calendar.HOUR_OF_DAY);
        r.minuto = c.get(java.util.Calendar.MINUTE);
        r.status = Reminder.AGENDADO;
        r.proximo = quando;
        Store.salvar(this, r);
        Scheduler.agendar(this, r);
        Toast.makeText(this, "Vai tocar em 10 segundos…", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == PEDIR_FOTO && data.getData() != null) {
            if (salvarFoto(data.getData())) {
                Ui.limparCache();
                montar();
            } else {
                Toast.makeText(this, "Não consegui abrir essa foto", Toast.LENGTH_LONG).show();
            }
        } else if (req == PEDIR_SOM) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            Ui.prefs(this).edit().putString("som", uri == null ? null : uri.toString()).apply();
            Toast.makeText(this, "Som salvo", Toast.LENGTH_SHORT).show();
        }
    }

    /** Copia a foto para dentro do app, já reduzida ao tamanho da tela. */
    private boolean salvarFoto(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int alvo = Math.max(dm.widthPixels, dm.heightPixels);
            int maior = Math.max(o.outWidth, o.outHeight);
            int amostra = 1;
            while (maior / (amostra * 2) >= alvo) amostra *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = amostra;
            Bitmap bmp;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, o2);
            }
            if (bmp == null) return false;
            int graus = 0;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                android.media.ExifInterface exif = new android.media.ExifInterface(in);
                int ori = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,
                        android.media.ExifInterface.ORIENTATION_NORMAL);
                if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_90) graus = 90;
                else if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_180) graus = 180;
                else if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_270) graus = 270;
            } catch (Exception ignored) {
            }
            if (graus != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(graus);
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
            try (FileOutputStream out = new FileOutputStream(Ui.papelArquivo(this))) {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
