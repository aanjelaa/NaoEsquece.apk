package br.com.naoesquece;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Chamado pelo Android na hora do alarme (ou do aviso antes da hora). */
public class AlarmReceiver extends BroadcastReceiver {
    static final String CANAL_AVISO = "aviso_antes_v1";

    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", -1);
        Reminder r = Store.pegar(c, id);
        if (r == null || !r.ativo()) return;

        if (Scheduler.AVISAR.equals(in.getAction())) {
            if (Reminder.AGENDADO.equals(r.status)) avisar(c, r);
            return;
        }

        r.status = Reminder.TOCANDO;
        Store.salvar(c, r);
        Intent s = new Intent(c, AlarmService.class).setAction(AlarmService.TOCAR).putExtra("id", id);
        c.startForegroundService(s);
    }

    private void avisar(Context c, Reminder r) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel canal = new NotificationChannel(CANAL_AVISO, "Aviso antes da hora",
                NotificationManager.IMPORTANCE_HIGH);
        canal.setDescription("Avisa alguns minutos antes do alarme");
        nm.createNotificationChannel(canal);

        long faltaMin = Math.max(1, Math.round((r.proximo - System.currentTimeMillis()) / 60_000.0));
        String falta;
        if (faltaMin >= 1440) {
            long dias = Math.round(faltaMin / 1440.0);
            falta = dias == 7 ? "1 semana" : dias + (dias == 1 ? " dia" : " dias");
        } else if (faltaMin >= 60 && faltaMin % 60 == 0) {
            falta = (faltaMin / 60) + " h";
        } else {
            falta = faltaMin + " min";
        }
        PendingIntent abrir = PendingIntent.getActivity(c, 40000 + r.id,
                new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent editar = PendingIntent.getActivity(c, 45000 + r.id,
                new Intent(c, EditActivity.class).putExtra("id", r.id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String titulo = "Daqui a " + falta + ": " + r.tituloOuPadrao();
        String quando = Reminder.diaTexto(r.proximo) + " às " + Reminder.so_hora(r.proximo);
        String texto = r.nota == null || r.nota.trim().isEmpty()
                ? "Toca " + quando
                : "Toca " + quando + "\n" + r.nota.trim();
        Notification n = new Notification.Builder(c, CANAL_AVISO)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(titulo)
                .setContentText(texto)
                .setStyle(new Notification.BigTextStyle().bigText(texto))
                .setColor(Ui.cor(c))
                .setContentIntent(abrir)
                .setAutoCancel(true)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(c, R.drawable.ic_notif),
                        "📅 Mudar data/hora", editar).build())
                .build();
        nm.notify(40000 + r.id, n);
    }
}
