package br.com.naoesquece;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Chamado pelo Android na hora do alarme. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", -1);
        Reminder r = Store.pegar(c, id);
        if (r == null || !r.ativo()) return;
        r.status = Reminder.TOCANDO;
        Store.salvar(c, r);
        Intent s = new Intent(c, AlarmService.class).setAction(AlarmService.TOCAR).putExtra("id", id);
        c.startForegroundService(s);
    }
}
