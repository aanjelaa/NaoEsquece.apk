package br.com.naoesquece;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Chamado pelo Android na hora do alarme (ou do aviso antes da hora). */
public class AlarmReceiver extends BroadcastReceiver {
    static final String CANAL_AVISO = "aviso_antes_v1";

    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", -1);
        Reminder r = Store.pegar(c, id);
        if (r == null || !r.ativo()) return;

        if (Scheduler.AVISAR.equals(in.getAction())) {
            if (Reminder.AGENDADO.equals(r.status)) avisar(c, r);
            return;
        }

        r.status = Reminder.TOCANDO;
        Store.salvar(c, r);
        Intent s = new Intent(c, AlarmService.class).setAction(AlarmService.TOCAR).putExtra("id", id);
        c.startForegroundService(s);
    }

    private void avisar(Context c, Reminder r) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel canal = new NotificationChannel(CANAL_AVISO, "Aviso antes da hora",
                NotificationManager.IMPORTANCE_HIGH);
        canal.setDescription("Avisa alguns minutos antes do alarme");
        nm.createNotificationChannel(canal);

        long falta = Math.max(1, Math.round((r.proximo - System.currentTimeMillis()) / 60_000.0));
        PendingIntent abrir = PendingIntent.getActivity(c, 40000 + r.id,
                new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String titulo = "Daqui a " + falta + " min: " + r.tituloOuPadrao();
        String texto = r.nota == null || r.nota.trim().isEmpty()
                ? "Às " + r.horaTexto() + " o alarme vai tocar"
                : r.nota.trim();
        Notification n = new Notification.Builder(c, CANAL_AVISO)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(titulo)
                .setContentText(texto)
                .setStyle(new Notification.BigTextStyle().bigText(texto))
                .setColor(Ui.cor(c))
                .setContentIntent(abrir)
                .setAutoCancel(true)
                .build();
        nm.notify(40000 + r.id, n);
    }
}
