package br.com.naoesquece;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Guarda os lembretes no próprio celular. */
public class Store {
    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("dados", Context.MODE_PRIVATE);
    }

    public static synchronized List<Reminder> todos(Context c) {
        List<Reminder> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("lembretes", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Reminder.fromJson(a.getJSONObject(i)));
        } catch (JSONException ignored) {
        }
        return out;
    }

    public static synchronized Reminder pegar(Context c, int id) {
        for (Reminder r : todos(c)) if (r.id == id) return r;
        return null;
    }

    public static synchronized void salvar(Context c, Reminder r) {
        List<Reminder> lista = todos(c);
        if (r.id <= 0) {
            int prox = p(c).getInt("proximoId", 1);
            r.id = prox;
            p(c).edit().putInt("proximoId", prox + 1).commit();
        }
        boolean achou = false;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).id == r.id) {
                lista.set(i, r);
                achou = true;
                break;
            }
        }
        if (!achou) lista.add(r);
        gravar(c, lista);
    }

    public static synchronized void apagar(Context c, int id) {
        List<Reminder> lista = todos(c);
        List<Reminder> nova = new ArrayList<>();
        for (Reminder r : lista) if (r.id != id) nova.add(r);
        gravar(c, nova);
    }

    /** Troca todos os lembretes (usado ao restaurar um backup). */
    public static synchronized void substituirTudo(Context c, List<Reminder> lista) {
        int maior = 0;
        for (Reminder r : lista) maior = Math.max(maior, r.id);
        int prox = Math.max(p(c).getInt("proximoId", 1), maior + 1);
        p(c).edit().putInt("proximoId", prox).commit();
        gravar(c, lista);
    }

    private static void gravar(Context c, List<Reminder> lista) {
        JSONArray a = new JSONArray();
        for (Reminder r : lista) {
            try {
                a.put(r.toJson());
            } catch (JSONException ignored) {
            }
        }
        p(c).edit().putString("lembretes", a.toString()).commit();
        try {
            ProximoWidget.atualizar(c);
        } catch (Exception ignored) {
        }
        Backup.agendar(c);
    }
}
