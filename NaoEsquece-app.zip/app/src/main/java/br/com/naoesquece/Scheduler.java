package br.com.naoesquece;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Agenda os alarmes no sistema do Android. */
public class Scheduler {
    public static final String DISPARAR = "br.com.naoesquece.DISPARAR";
    public static final String AVISAR = "br.com.naoesquece.AVISAR";

    static PendingIntent aviso(Context c, int id) {   // versão antiga (um aviso só)
        Intent i = new Intent(c, AlarmReceiver.class).setAction(AVISAR).putExtra("id", id);
        return PendingIntent.getBroadcast(c, 30000 + id, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent aviso(Context c, int id, int opcao) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(AVISAR)
                .putExtra("id", id).putExtra("opcao", opcao);
        return PendingIntent.getBroadcast(c, 100000 + id * 8 + opcao, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void cancelarAvisos(Context c, AlarmManager am, int id) {
        am.cancel(aviso(c, id));
        for (int i = 0; i < Reminder.AVISO_OPCOES.length; i++) am.cancel(aviso(c, id, i));
    }

    static PendingIntent disparo(Context c, int id) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(DISPARAR).putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static void agendar(Context c, Reminder r) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = disparo(c, r.id);
        cancelarAvisos(c, am, r.id);
        if (!r.ativo()) {
            am.cancel(pi);
            return;
        }
        boolean exato = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (Reminder.AGENDADO.equals(r.status)) {
            for (int i = 0; i < Reminder.AVISO_OPCOES.length; i++) {
                if ((r.avisos & (1 << i)) == 0) continue;
                long quandoAvisar = r.proximo - Reminder.AVISO_OPCOES[i] * 60_000L;
                if (quandoAvisar <= System.currentTimeMillis() + 5_000) continue;
                PendingIntent avisoPi = aviso(c, r.id, i);
                if (exato) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, quandoAvisar, avisoPi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, quandoAvisar, avisoPi);
            }
        }
        Intent mostrar = new Intent(c, MainActivity.class);
        PendingIntent mostrarPi = PendingIntent.getActivity(c, 50000 + r.id, mostrar,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if (!exato) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.proximo, pi);
            return;
        }
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(r.proximo, mostrarPi), pi);
    }

    public static void cancelar(Context c, int id) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        am.cancel(disparo(c, id));
        cancelarAvisos(c, am, id);
    }

    /** Marca como feito: se repete, agenda a próxima vez; senão encerra. */
    public static void marcarFeito(Context c, Reminder r) {
        r.sonecas = 0;
        if (r.repete == Reminder.REPETE_NAO) {
            r.status = Reminder.FEITO;
            Store.salvar(c, r);
            cancelar(c, r.id);
        } else {
            r.status = Reminder.AGENDADO;
            r.proximo = r.calcularProximo(System.currentTimeMillis());
            Store.salvar(c, r);
            agendar(c, r);
        }
    }

    /** Depois de reiniciar o celular ou mudar a hora: reagenda tudo.
     *  Alarme perdido enquanto o celular estava desligado toca logo em seguida. */
    public static void reagendarTodos(Context c, boolean reiniciou) {
        long agora = System.currentTimeMillis();
        for (Reminder r : Store.todos(c)) {
            if (!r.ativo()) continue;
            if (Reminder.TOCANDO.equals(r.status)) {
                if (!reiniciou) continue; // está tocando agora, deixa tocar
                r.status = Reminder.SONECA;
                r.proximo = agora + 30_000;
            } else if (r.proximo <= agora) {
                if (Reminder.AGENDADO.equals(r.status) && r.repete != Reminder.REPETE_NAO
                        && agora - r.proximo > 12 * 60 * 60 * 1000L) {
                    r.proximo = r.calcularProximo(agora);
                } else {
                    r.proximo = agora + 30_000;
                }
            }
            Store.salvar(c, r);
            agendar(c, r);
        }
    }
}
